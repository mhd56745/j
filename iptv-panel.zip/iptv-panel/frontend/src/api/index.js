import axios from 'axios'

const api = axios.create({
  baseURL: '/api',
  headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
})

// Attach auth token
api.interceptors.request.use(config => {
  const token = localStorage.getItem('iptv_token')
  if (token) config.headers.Authorization = `Bearer ${token}`
  return config
})

// Handle 401
api.interceptors.response.use(
  res => res,
  err => {
    if (err.response?.status === 401) {
      localStorage.removeItem('iptv_token')
      window.location.href = '/login'
    }
    return Promise.reject(err)
  }
)

export default api

// Convenience helpers
export const adminApi = {
  dashboard: () => api.get('/admin/dashboard'),
  // Channels
  getChannels: (params) => api.get('/admin/channels', { params }),
  getChannel: (id) => api.get(`/admin/channels/${id}`),
  createChannel: (data) => api.post('/admin/channels', data),
  updateChannel: (id, data) => api.put(`/admin/channels/${id}`, data),
  deleteChannel: (id) => api.delete(`/admin/channels/${id}`),
  bulkImportChannels: (formData) => api.post('/admin/channels/bulk-import', formData, { headers: { 'Content-Type': 'multipart/form-data' } }),
  exportM3u: (params) => api.get('/admin/channels/export/m3u', { params, responseType: 'blob' }),
  // Streams
  getStreams: (params) => api.get('/admin/streams', { params }),
  startRestream: (data) => api.post('/admin/streams/restream', data),
  stopStream: (id) => api.post(`/admin/streams/${id}/stop`),
  getStreamStats: () => api.get('/admin/streams/stats'),
  getStreamLogs: (params) => api.get('/admin/streams/logs', { params }),
  // Servers
  getServers: (params) => api.get('/admin/servers', { params }),
  getServer: (id) => api.get(`/admin/servers/${id}`),
  createServer: (data) => api.post('/admin/servers', data),
  updateServer: (id, data) => api.put(`/admin/servers/${id}`, data),
  deleteServer: (id) => api.delete(`/admin/servers/${id}`),
  healthCheck: (id) => api.post(`/admin/servers/${id}/health-check`),
  rtmpStats: (id) => api.get(`/admin/servers/${id}/rtmp-stats`),
  // Users
  getUsers: (params) => api.get('/admin/users', { params }),
  getUser: (id) => api.get(`/admin/users/${id}`),
  createUser: (data) => api.post('/admin/users', data),
  updateUser: (id, data) => api.put(`/admin/users/${id}`, data),
  deleteUser: (id) => api.delete(`/admin/users/${id}`),
  regenerateApiKey: (id) => api.post(`/admin/users/${id}/regenerate-api-key`),
  bulkCreateUsers: (data) => api.post('/admin/users/bulk-create', data),
  // Categories
  getCategories: (params) => api.get('/admin/categories', { params }),
  createCategory: (data) => api.post('/admin/categories', data),
  updateCategory: (id, data) => api.put(`/admin/categories/${id}`, data),
  deleteCategory: (id) => api.delete(`/admin/categories/${id}`),
  // Auth
  login: (credentials) => api.post('/auth/login', credentials),
  logout: () => api.post('/auth/logout'),
  me: () => api.get('/auth/me'),
}