<template>
  <div class="min-h-screen flex items-center justify-center bg-gray-950 px-4">
    <div class="w-full max-w-md">
      <div class="text-center mb-8">
        <div class="inline-flex items-center justify-center w-16 h-16 bg-blue-600/20 rounded-2xl mb-4">
          <svg class="w-8 h-8 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
          </svg>
        </div>
        <h1 class="text-2xl font-bold text-white">IPTV Panel</h1>
        <p class="text-gray-400 mt-1">Admin Dashboard</p>
      </div>

      <form @submit.prevent="handleLogin" class="card space-y-5">
        <div v-if="error" class="bg-red-900/30 border border-red-800 rounded-lg p-3 text-red-400 text-sm">
          {{ error }}
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-300 mb-1.5">Email</label>
          <input v-model="form.email" type="email" required placeholder="admin@iptv.local"
                 class="input-field" />
        </div>

        <div>
          <label class="block text-sm font-medium text-gray-300 mb-1.5">Password</label>
          <input v-model="form.password" type="password" required placeholder="••••••••"
                 class="input-field" />
        </div>

        <button type="submit" :disabled="loading"
                class="btn btn-primary w-full py-3 text-base">
          <span v-if="loading" class="inline-block w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></span>
          {{ loading ? 'Signing in...' : 'Sign In' }}
        </button>
      </form>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { adminApi } from '../api'

const router = useRouter()
const form = ref({ email: '', password: '' })
const loading = ref(false)
const error = ref('')

async function handleLogin() {
  loading.value = true
  error.value = ''
  try {
    const res = await adminApi.login(form.value)
    localStorage.setItem('iptv_token', res.data.data.token)
    localStorage.setItem('iptv_user', JSON.stringify(res.data.data.user))
    router.push('/')
  } catch (err) {
    error.value = err.response?.data?.message || 'Login failed. Please try again.'
  } finally {
    loading.value = false
  }
}
</script>