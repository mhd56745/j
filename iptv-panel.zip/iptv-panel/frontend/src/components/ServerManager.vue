<template>
  <div class="p-6 animate-fadeIn">
    <div class="flex items-center justify-between mb-6">
      <div>
        <h1 class="text-2xl font-bold text-white">Servers</h1>
        <p class="text-gray-400 mt-1">Manage streaming server infrastructure</p>
      </div>
      <button @click="openForm()" class="btn btn-primary btn-sm">+ Add Server</button>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      <div v-for="srv in servers" :key="srv.id" class="card">
        <div class="flex items-center justify-between mb-3">
          <h3 class="font-semibold text-white">{{ srv.name }}</h3>
          <span class="badge" :class="srv.status === 'online' ? 'badge-green' : srv.status === 'maintenance' ? 'badge-yellow' : 'badge-red'">
            {{ srv.status }}
          </span>
        </div>

        <div class="space-y-2 text-sm">
          <div class="flex justify-between">
            <span class="text-gray-400">IP Address</span>
            <span class="text-gray-200 font-mono">{{ srv.ip_address }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-400">Location</span>
            <span class="text-gray-300">{{ srv.location || '-' }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-400">RTMP Port</span>
            <span class="text-gray-300">{{ srv.rtmp_port }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-400">HLS Port</span>
            <span class="text-gray-300">{{ srv.hls_port }}</span>
          </div>
          <div class="flex justify-between">
            <span class="text-gray-400">Load</span>
            <span :class="srv.load_percent > 80 ? 'text-red-400' : 'text-emerald-400'">{{ srv.load_percent }}%</span>
          </div>
        </div>

        <!-- Load Bar -->
        <div class="mt-3 w-full bg-gray-800 rounded-full h-2">
          <div class="h-2 rounded-full transition-all"
               :class="srv.load_percent > 80 ? 'bg-red-500' : srv.load_percent > 50 ? 'bg-yellow-500' : 'bg-emerald-500'"
               :style="{ width: Math.min(srv.load_percent, 100) + '%' }"></div>
        </div>
        <div class="text-xs text-gray-500 mt-1">{{ srv.current_connections || 0 }} / {{ srv.max_connections }} connections</div>

        <!-- Actions -->
        <div class="flex gap-2 mt-4 pt-3 border-t border-gray-800">
          <button @click="checkHealth(srv)" class="btn btn-secondary btn-sm flex-1">Health Check</button>
          <button @click="getStats(srv)" class="btn btn-secondary btn-sm flex-1">RTMP Stats</button>
          <button @click="openForm(srv)" class="btn btn-secondary btn-sm">Edit</button>
          <button @click="deleteServer(srv)" class="btn btn-danger btn-sm">Del</button>
        </div>
      </div>
    </div>

    <!-- Server Form Modal -->
    <div v-if="showForm" class="fixed inset-0 bg-black/60 flex items-center justify-center z-50" @click.self="showForm = false">
      <div class="card w-full max-w-lg">
        <h3 class="text-lg font-bold text-white mb-4">{{ form.id ? 'Edit Server' : 'Add Server' }}</h3>
        <form @submit.prevent="saveServer" class="space-y-4">
          <div><label class="text-sm text-gray-300">Name *</label><input v-model="form.name" class="input-field mt-1" required /></div>
          <div><label class="text-sm text-gray-300">Hostname *</label><input v-model="form.hostname" class="input-field mt-1" required /></div>
          <div><label class="text-sm text-gray-300">IP Address *</label><input v-model="form.ip_address" class="input-field mt-1" required placeholder="1.2.3.4" /></div>
          <div class="grid grid-cols-3 gap-3">
            <div><label class="text-sm text-gray-300">RTMP Port</label><input v-model.number="form.rtmp_port" type="number" class="input-field mt-1" /></div>
            <div><label class="text-sm text-gray-300">HTTP Port</label><input v-model.number="form.http_port" type="number" class="input-field mt-1" /></div>
            <div><label class="text-sm text-gray-300">HLS Port</label><input v-model.number="form.hls_port" type="number" class="input-field mt-1" /></div>
          </div>
          <div><label class="text-sm text-gray-300">Max Connections</label><input v-model.number="form.max_connections" type="number" class="input-field mt-1" /></div>
          <div><label class="text-sm text-gray-300">Location</label><input v-model="form.location" class="input-field mt-1" placeholder="US East, EU West..." /></div>
          <div><label class="text-sm text-gray-300">Notes</label><textarea v-model="form.notes" class="input-field mt-1" rows="2"></textarea></div>
          <div class="flex gap-2 justify-end pt-2">
            <button type="button" @click="showForm = false" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">{{ form.id ? 'Update' : 'Create' }}</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { adminApi } from '../api'

const servers = ref([])
const showForm = ref(false)
const emptyForm = { id: null, name: '', hostname: '', ip_address: '', rtmp_port: 1935, http_port: 8080, hls_port: 8080, max_connections: 1000, location: '', notes: '' }
const form = ref({ ...emptyForm })

onMounted(loadServers)

async function loadServers() {
  try { const res = await adminApi.getServers(); servers.value = res.data.data.data } catch {}
}

function openForm(srv = null) { form.value = srv ? { ...srv } : { ...emptyForm }; showForm.value = true }

async function saveServer() {
  try {
    if (form.value.id) await adminApi.updateServer(form.value.id, form.value)
    else await adminApi.createServer(form.value)
    showForm.value = false; loadServers()
  } catch (err) { alert(err.response?.data?.message || 'Error') }
}

async function deleteServer(srv) {
  if (!confirm(`Delete server "${srv.name}"?`)) return
  try { await adminApi.deleteServer(srv.id); loadServers() } catch (err) { alert(err.response?.data?.message) }
}

async function checkHealth(srv) {
  try {
    const res = await adminApi.healthCheck(srv.id)
    alert(`Server: ${res.data.data.status}\nResponse time: ${res.data.data.response_time_ms}ms`)
    loadServers()
  } catch (err) { alert('Health check failed') }
}

async function getStats(srv) {
  try {
    const res = await adminApi.rtmpStats(srv.id)
    console.log('RTMP Stats:', res.data.data)
    alert('RTMP stats logged to console (F12).')
  } catch (err) { alert('Failed to fetch RTMP stats') }
}
</script>