<template>
  <div class="p-6 animate-fadeIn">
    <div class="mb-6">
      <h1 class="text-2xl font-bold text-white">Dashboard</h1>
      <p class="text-gray-400 mt-1">System overview and real-time statistics</p>
    </div>

    <!-- Stats Cards -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
      <div v-for="stat in statCards" :key="stat.label" class="stat-card">
        <div class="flex items-center justify-between mb-3">
          <span class="text-gray-400 text-sm">{{ stat.label }}</span>
          <span v-html="stat.icon" class="text-gray-600"></span>
        </div>
        <div class="text-2xl font-bold" :class="stat.color">{{ stat.value }}</div>
        <p class="text-xs text-gray-500 mt-1">{{ stat.sub }}</p>
      </div>
    </div>

    <!-- Servers & Bandwidth -->
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
      <div class="card lg:col-span-2">
        <h3 class="text-sm font-semibold text-gray-300 mb-4">Server Load</h3>
        <div v-for="server in data?.servers" :key="server.id" class="mb-3 last:mb-0">
          <div class="flex justify-between text-sm mb-1">
            <span class="text-gray-300">{{ server.name }}</span>
            <span class="text-gray-400">{{ server.load_percent }}%</span>
          </div>
          <div class="w-full bg-gray-800 rounded-full h-2">
            <div class="h-2 rounded-full transition-all"
                 :class="server.load_percent > 80 ? 'bg-red-500' : server.load_percent > 50 ? 'bg-yellow-500' : 'bg-emerald-500'"
                 :style="{ width: Math.min(server.load_percent, 100) + '%' }"></div>
          </div>
        </div>
        <div v-if="!data?.servers?.length" class="text-gray-500 text-sm">No servers configured</div>
      </div>

      <div class="card">
        <h3 class="text-sm font-semibold text-gray-300 mb-4">Quick Stats</h3>
        <div class="space-y-3">
          <div class="flex justify-between"><span class="text-gray-400 text-sm">Online Channels</span><span class="text-emerald-400 font-medium">{{ data?.channels?.active || 0 }}/{{ data?.channels?.total || 0 }}</span></div>
          <div class="flex justify-between"><span class="text-gray-400 text-sm">Restream Channels</span><span class="text-blue-400 font-medium">{{ data?.channels?.restream || 0 }}</span></div>
          <div class="flex justify-between"><span class="text-gray-400 text-sm">Peak Viewers Today</span><span class="text-yellow-400 font-medium">{{ data?.streams?.peak_viewers_today || 0 }}</span></div>
          <div class="flex justify-between"><span class="text-gray-400 text-sm">Active Users</span><span class="text-purple-400 font-medium">{{ data?.users?.active || 0 }}</span></div>
          <div class="flex justify-between"><span class="text-gray-400 text-sm">Bandwidth Out</span><span class="text-gray-200 font-medium">{{ data?.bandwidth?.formatted || '0 B' }}</span></div>
        </div>
      </div>
    </div>

    <!-- Recent Streams -->
    <div class="card">
      <h3 class="text-sm font-semibold text-gray-300 mb-4">Recent Streams</h3>
      <div class="table-container">
        <table>
          <thead><tr>
            <th>Channel</th><th>User</th><th>Server</th><th>Status</th><th>Viewers</th><th>Duration</th><th>Started</th>
          </tr></thead>
          <tbody>
            <tr v-for="s in data?.recent_streams" :key="s.id">
              <td class="text-gray-200">{{ s.channel || '-' }}</td>
              <td class="text-gray-400">{{ s.user || '-' }}</td>
              <td class="text-gray-400">{{ s.server || '-' }}</td>
              <td>
                <span class="badge" :class="statusBadge(s.status)">{{ s.status }}</span>
              </td>
              <td class="text-gray-300">{{ s.viewer_count }}</td>
              <td class="text-gray-400">{{ s.duration_formatted }}</td>
              <td class="text-gray-500 text-xs">{{ formatTime(s.created_at) }}</td>
            </tr>
          </tbody>
        </table>
        <div v-if="!data?.recent_streams?.length" class="text-gray-500 text-sm text-center py-6">No recent streams</div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'
import { adminApi } from '../api'

const data = ref(null)

onMounted(async () => {
  try { const res = await adminApi.dashboard(); data.value = res.data.data } catch {}
})

const statCards = computed(() => [
  { label: 'Active Streams', value: data.value?.streams?.active || 0, sub: 'Live now', color: 'text-emerald-400', icon: '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>' },
  { label: 'Total Viewers', value: data.value?.streams?.total_viewers || 0, sub: 'Across all streams', color: 'text-blue-400', icon: '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>' },
  { label: 'Total Channels', value: data.value?.channels?.total || 0, sub: `${data.value?.channels?.live || 0} live channels`, color: 'text-purple-400', icon: '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 4V2a1 1 0 011-1h8a1 1 0 011 1v2m-9 0h10"/></svg>' },
  { label: 'Total Users', value: data.value?.users?.total || 0, sub: `${data.value?.users?.online_viewers || 0} currently online`, color: 'text-yellow-400', icon: '<svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1z"/></svg>' },
])

function statusBadge(status) {
  const map = { active: 'badge-green', starting: 'badge-yellow', stopping: 'badge-yellow', ended: 'badge-gray', error: 'badge-red' }
  return map[status] || 'badge-gray'
}

function formatTime(iso) {
  if (!iso) return '-'
  return new Date(iso).toLocaleTimeString()
}
</script>