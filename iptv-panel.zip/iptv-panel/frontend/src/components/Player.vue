<template>
  <div class="p-6 animate-fadeIn">
    <div class="mb-6">
      <h1 class="text-2xl font-bold text-white">Stream Player</h1>
      <p class="text-gray-400 mt-1">Preview live channels with HLS.js</p>
    </div>

    <div class="max-w-4xl">
      <!-- Channel Selector -->
      <div class="card mb-4">
        <label class="text-sm text-gray-300 block mb-2">Select Channel</label>
        <select v-model="selectedChannel" @change="playChannel" class="input-field">
          <option value="">Choose a channel...</option>
          <option v-for="ch in channels" :key="ch.id" :value="ch.id">{{ ch.name }} ({{ ch.stream_format }})</option>
        </select>
      </div>

      <!-- Player -->
      <div class="card p-0 overflow-hidden">
        <div class="relative bg-black aspect-video">
          <video ref="videoEl" controls class="w-full h-full" autoplay></video>
          <div v-if="!playing" class="absolute inset-0 flex items-center justify-center bg-gray-900/80">
            <p class="text-gray-400">Select a channel to start playing</p>
          </div>
        </div>

        <!-- Stream Info Bar -->
        <div v-if="currentStream" class="px-4 py-3 bg-gray-800/50 flex items-center justify-between">
          <div class="flex items-center gap-4 text-sm">
            <span class="text-gray-300">{{ currentStream.channel?.name }}</span>
            <span class="badge badge-green">Live</span>
            <span class="text-gray-400">Viewers: {{ currentStream.viewer_count || 0 }}</span>
          </div>
          <span class="text-gray-500 text-xs">{{ currentStream.hls_url }}</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import Hls from 'hls.js'
import { adminApi } from '../api'

const videoEl = ref(null)
const channels = ref([])
const selectedChannel = ref('')
const playing = ref(false)
const currentStream = ref(null)
let hls = null

onMounted(loadChannels)
onUnmounted(() => { if (hls) hls.destroy() })

async function loadChannels() {
  try {
    const res = await adminApi.getChannels({ status: 'online', per_page: 200 })
    channels.value = res.data.data.data
  } catch {}
}

async function playChannel() {
  if (hls) { hls.destroy(); hls = null }
  playing.value = false
  currentStream.value = null

  if (!selectedChannel.value) return

  const ch = channels.value.find(c => c.id === parseInt(selectedChannel.value))
  if (!ch?.hls_url) { alert('No HLS URL available for this channel'); return }

  currentStream.value = ch

  const video = videoEl.value
  if (Hls.isSupported()) {
    hls = new Hls({ enableWorker: true, lowLatencyMode: true })
    hls.loadSource(ch.hls_url)
    hls.attachMedia(video)
    hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play(); playing.value = true })
    hls.on(Hls.Events.ERROR, (_, data) => {
      if (data.fatal) { console.error('HLS Error:', data); playing.value = false }
    })
  } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
    video.src = ch.hls_url
    video.addEventListener('loadedmetadata', () => { video.play(); playing.value = true })
  }
}
</script>