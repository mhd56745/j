<template>
  <div class="p-6 animate-fadeIn">
    <div class="flex items-center justify-between mb-6">
      <div>
        <h1 class="text-2xl font-bold text-white">Streams</h1>
        <p class="text-gray-400 mt-1">Monitor and control active streams</p>
      </div>
      <button @click="loadStreams" class="btn btn-secondary btn-sm">Refresh</button>
    </div>

    <!-- Stream Stats Summary -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
      <div class="stat-card">
        <div class="text-gray-400 text-sm mb-1">Active Streams</div>
        <div class="text-xl font-bold text-emerald-400">{{ stats.active_streams || 0 }}</div>
      </div>
      <div class="stat-card">
        <div class="text-gray-400 text-sm mb-1">Total Viewers</div>
        <div class="text-xl font-bold text-blue-400">{{ stats.total_viewers || 0 }}</div>
      </div>
      <div class="stat-card">
        <div class="text-gray-400 text-sm mb-1">Online Channels</div>
        <div class="text-xl font-bold text-purple-400">{{ stats.online_channels || 0 }}</div>
      </div>
      <div class="stat-card">
        <div class="text-gray-400 text-sm mb-1">Recent Errors</div>
        <div class="text-xl font-bold text-red-400">{{ stats.recent_errors || 0 }}</div>
      </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4 flex flex-wrap gap-3 items-center">
      <select v-model="filters.status" @change="loadStreams" class="input-field w-40">
        <option value="">All Status</option>
        <option value="starting">Starting</option>
        <option value="active">Active</option>
        <option value="stopping">Stopping</option>
        <option value="ended">Ended</option>
        <option value="error">Error</option>
      </select>
    </div>

    <!-- Streams Table -->
    <div class="card p-0">
      <div class="table-container">
        <table>
          <thead><tr>
            <th>Channel</th><th>User</th><th>Server</th><th>Stream Key</th><th>Status</th><th>Viewers</th><th>Duration</th><th>Started</th><th>Actions</th>
          </tr></thead>
          <tbody>
            <tr v-for="s in streams" :key="s.id">
              <td class="text-gray-200 font-medium">{{ s.channel?.name || '-' }}</td>
              <td class="text-gray-400">{{ s.user?.username || '-' }}</td>
              <td class="text-gray-400">{{ s.server?.name || '-' }}</td>
              <td class="text-gray-500 font-mono text-xs">{{ s.stream_key?.substring(0, 8) }}...</td>
              <td><span class="badge" :class="statusBadge(s.status)">{{ s.status }}</span></td>
              <td class="text-gray-300">{{ s.viewer_count }}</td>
              <td class="text-gray-400">{{ s.duration_formatted }}</td>
              <td class="text-gray-500 text-xs">{{ formatTime(s.start_time) }}</td>
              <td>
                <button v-if="s.status === 'active' || s.status === 'starting'" @click="stopStream(s)" class="btn btn-danger btn-sm">Stop</button>
                <span v-else class="text-gray-600 text-xs">-</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="!streams.length" class="text-gray-500 text-sm text-center py-10">No streams found</div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { adminApi } from '../api'

const streams = ref([])
const stats = ref({})
const filters = ref({ status: '' })
let refreshTimer = null

onMounted(() => {
  loadStreams()
  loadStats()
  refreshTimer = setInterval(() => { loadStreams(); loadStats() }, 10000)
})

onUnmounted(() => { if (refreshTimer) clearInterval(refreshTimer) })

async function loadStreams() {
  try {
    const res = await adminApi.getStreams(filters.value)
    streams.value = res.data.data.data
  } catch {}
}

async function loadStats() {
  try {
    const res = await adminApi.getStreamStats()
    stats.value = res.data.data
  } catch {}
}

async function stopStream(s) {
  if (!confirm(`Stop stream for "${s.channel?.name}"?`)) return
  try { await adminApi.stopStream(s.id); loadStreams() } catch {}
}

function statusBadge(status) {
  const m = { active: 'badge-green', starting: 'badge-yellow', stopping: 'badge-yellow', ended: 'badge-gray', error: 'badge-red' }
  return m[status] || 'badge-gray'
}

function formatTime(iso) {
  if (!iso) return '-'
  return new Date(iso).toLocaleString()
}
</script>