<template>
  <div class="p-6 animate-fadeIn">
    <div class="flex items-center justify-between mb-6">
      <div>
        <h1 class="text-2xl font-bold text-white">Channels</h1>
        <p class="text-gray-400 mt-1">Manage your IPTV channels and sources</p>
      </div>
      <div class="flex gap-2">
        <button @click="showImport = true" class="btn btn-secondary btn-sm">Import M3U</button>
        <button @click="exportM3u" class="btn btn-secondary btn-sm">Export M3U</button>
        <button @click="openForm()" class="btn btn-primary btn-sm">+ Add Channel</button>
      </div>
    </div>

    <!-- Filters -->
    <div class="card mb-4 flex flex-wrap gap-3 items-center">
      <input v-model="filters.search" @input="loadChannels" placeholder="Search channels..." class="input-field w-64" />
      <select v-model="filters.type" @change="loadChannels" class="input-field w-40">
        <option value="">All Types</option>
        <option value="live">Live</option>
        <option value="movie">Movie</option>
        <option value="series">Series</option>
      </select>
      <select v-model="filters.status" @change="loadChannels" class="input-field w-40">
        <option value="">All Status</option>
        <option value="online">Online</option>
        <option value="offline">Offline</option>
      </select>
      <label class="flex items-center gap-2 text-sm text-gray-400">
        <input type="checkbox" v-model="filters.is_restream" @change="loadChannels" class="rounded" />
        Restream only
      </label>
    </div>

    <!-- Table -->
    <div class="card p-0">
      <div class="table-container">
        <table>
          <thead><tr>
            <th>Logo</th><th>Name</th><th>Category</th><th>Type</th><th>Format</th><th>Status</th><th>Viewers</th><th>Actions</th>
          </tr></thead>
          <tbody>
            <tr v-for="ch in channels" :key="ch.id">
              <td>
                <img v-if="ch.logo_url" :src="ch.logo_url" class="w-8 h-8 rounded object-contain bg-gray-800" />
                <div v-else class="w-8 h-8 bg-gray-800 rounded flex items-center justify-center text-xs text-gray-500">TV</div>
              </td>
              <td class="text-gray-200 font-medium">{{ ch.name }}</td>
              <td class="text-gray-400">{{ ch.category?.name || '-' }}</td>
              <td><span class="badge badge-blue">{{ ch.stream_type }}</span></td>
              <td class="text-gray-400 text-xs uppercase">{{ ch.stream_format }}</td>
              <td>
                <span class="badge" :class="ch.is_online ? 'badge-green' : 'badge-red'">
                  <span v-if="ch.is_online" class="w-1.5 h-1.5 bg-emerald-400 rounded-full mr-1.5 pulse-dot"></span>
                  {{ ch.is_online ? 'Online' : 'Offline' }}
                </span>
              </td>
              <td class="text-gray-300">{{ ch.viewer_count }}</td>
              <td class="space-x-1">
                <button @click="openForm(ch)" class="btn btn-secondary btn-sm">Edit</button>
                <button @click="deleteChannel(ch)" class="btn btn-danger btn-sm">Del</button>
                <button v-if="ch.is_restream" @click="startRestream(ch)" class="btn btn-success btn-sm">Restream</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-if="!channels.length" class="text-gray-500 text-sm text-center py-10">No channels found</div>
    </div>

    <!-- Channel Form Modal -->
    <div v-if="showForm" class="fixed inset-0 bg-black/60 flex items-center justify-center z-50" @click.self="showForm = false">
      <div class="card w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <h3 class="text-lg font-bold text-white mb-4">{{ form.id ? 'Edit Channel' : 'Add Channel' }}</h3>
        <form @submit.prevent="saveChannel" class="space-y-4">
          <div><label class="text-sm text-gray-300">Name *</label><input v-model="form.name" class="input-field mt-1" required /></div>
          <div><label class="text-sm text-gray-300">Category</label>
            <select v-model="form.category_id" class="input-field mt-1"><option value="">None</option><option v-for="c in categories" :key="c.id" :value="c.id">{{ c.name }}</option></select>
          </div>
          <div><label class="text-sm text-gray-300">Logo URL</label><input v-model="form.logo_url" class="input-field mt-1" placeholder="https://..." /></div>
          <div><label class="text-sm text-gray-300">Stream Source URL</label><input v-model="form.stream_source" class="input-field mt-1" placeholder="rtmp://... or https://..." /></div>
          <div class="grid grid-cols-2 gap-4">
            <div><label class="text-sm text-gray-300">Type</label>
              <select v-model="form.stream_type" class="input-field mt-1"><option value="live">Live</option><option value="movie">Movie</option><option value="series">Series</option></select>
            </div>
            <div><label class="text-sm text-gray-300">Format</label>
              <select v-model="form.stream_format" class="input-field mt-1"><option value="rtmp">RTMP</option><option value="hls">HLS/M3U8</option><option value="http">HTTP</option></select>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <input type="checkbox" v-model="form.is_restream" id="is_restream" class="rounded" />
            <label for="is_restream" class="text-sm text-gray-300">Enable Restreaming</label>
          </div>
          <div v-if="form.is_restream"><label class="text-sm text-gray-300">Restream URL</label><input v-model="form.restream_url" class="input-field mt-1" placeholder="https://source-stream.m3u8" /></div>
          <div class="flex gap-2 justify-end pt-2">
            <button type="button" @click="showForm = false" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">{{ form.id ? 'Update' : 'Create' }}</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Import M3U Modal -->
    <div v-if="showImport" class="fixed inset-0 bg-black/60 flex items-center justify-center z-50" @click.self="showImport = false">
      <div class="card w-full max-w-md">
        <h3 class="text-lg font-bold text-white mb-4">Import M3U Playlist</h3>
        <form @submit.prevent="handleImport" class="space-y-4">
          <div>
            <label class="text-sm text-gray-300">Select M3U File</label>
            <input type="file" accept=".m3u,.m3u8,.txt" @change="importFile = $event.target.files[0]" class="input-field mt-1" required />
          </div>
          <div><label class="text-sm text-gray-300">Type</label>
            <select v-model="importType" class="input-field mt-1"><option value="live">Live</option><option value="movie">Movie</option><option value="series">Series</option></select>
          </div>
          <div class="flex gap-2 justify-end pt-2">
            <button type="button" @click="showImport = false" class="btn btn-secondary">Cancel</button>
            <button type="submit" :disabled="importing" class="btn btn-primary">{{ importing ? 'Importing...' : 'Import' }}</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { adminApi } from '../api'

const channels = ref([])
const categories = ref([])
const showForm = ref(false)
const showImport = ref(false)
const importing = ref(false)
const importFile = ref(null)
const importType = ref('live')

const filters = ref({ search: '', type: '', status: '', is_restream: false })
const emptyForm = { id: null, name: '', category_id: '', logo_url: '', stream_source: '', stream_type: 'live', stream_format: 'http', is_restream: false, restream_url: '', is_active: true }
const form = ref({ ...emptyForm })

onMounted(() => { loadChannels(); loadCategories() })

async function loadChannels() {
  try {
    const res = await adminApi.getChannels(filters.value)
    channels.value = res.data.data.data
  } catch {}
}

async function loadCategories() {
  try {
    const res = await adminApi.getCategories({ per_page: 200 })
    categories.value = res.data.data.data
  } catch {}
}

function openForm(ch = null) {
  form.value = ch ? { ...ch } : { ...emptyForm }
  showForm.value = true
}

async function saveChannel() {
  try {
    if (form.value.id) {
      await adminApi.updateChannel(form.value.id, form.value)
    } else {
      await adminApi.createChannel(form.value)
    }
    showForm.value = false
    loadChannels()
  } catch (err) {
    alert(err.response?.data?.message || 'Error saving channel')
  }
}

async function deleteChannel(ch) {
  if (!confirm(`Delete "${ch.name}"?`)) return
  try { await adminApi.deleteChannel(ch.id); loadChannels() } catch {}
}

async function startRestream(ch) {
  try { await adminApi.startRestream({ channel_id: ch.id }); alert('Restream started!') } catch (err) { alert(err.response?.data?.message || 'Error') }
}

async function handleImport() {
  if (!importFile.value) return
  importing.value = true
  try {
    const fd = new FormData()
    fd.append('file', importFile.value)
    fd.append('stream_type', importType.value)
    const res = await adminApi.bulkImportChannels(fd)
    alert(`Imported ${res.data.data.imported} channels`)
    showImport.value = false
    loadChannels()
  } catch (err) {
    alert(err.response?.data?.message || 'Import failed')
  } finally { importing.value = false }
}

async function exportM3u() {
  try {
    const res = await adminApi.exportM3u(filters.value)
    const url = window.URL.createObjectURL(new Blob([res.data]))
    const a = document.createElement('a'); a.href = url; a.download = 'channels.m3u'; a.click()
  } catch {}
}
</script>