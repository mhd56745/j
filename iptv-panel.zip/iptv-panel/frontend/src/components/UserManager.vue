<template>
  <div class="p-6 animate-fadeIn">
    <div class="flex items-center justify-between mb-6">
      <div>
        <h1 class="text-2xl font-bold text-white">Users</h1>
        <p class="text-gray-400 mt-1">Manage viewers, resellers, and access</p>
      </div>
      <button @click="openForm()" class="btn btn-primary btn-sm">+ Add User</button>
    </div>

    <!-- Filters -->
    <div class="card mb-4 flex flex-wrap gap-3 items-center">
      <input v-model="filters.search" @input="loadUsers" placeholder="Search users..." class="input-field w-64" />
      <select v-model="filters.role" @change="loadUsers" class="input-field w-40">
        <option value="">All Roles</option>
        <option value="admin">Admin</option>
        <option value="reseller">Reseller</option>
        <option value="viewer">Viewer</option>
      </select>
    </div>

    <!-- Users Table -->
    <div class="card p-0">
      <div class="table-container">
        <table>
          <thead><tr>
            <th>Username</th><th>Email</th><th>Role</th><th>Status</th><th>Max Conn</th><th>Expires</th><th>API Key</th><th>Actions</th>
          </tr></thead>
          <tbody>
            <tr v-for="u in users" :key="u.id">
              <td class="text-gray-200 font-medium">{{ u.username }}</td>
              <td class="text-gray-400">{{ u.email }}</td>
              <td><span class="badge" :class="{ 'badge-red': u.role === 'admin', 'badge-yellow': u.role === 'reseller', 'badge-blue': u.role === 'viewer' }">{{ u.role }}</span></td>
              <td>
                <span v-if="u.is_expired" class="badge badge-red">Expired</span>
                <span v-else-if="u.status" class="badge badge-green">Active</span>
                <span v-else class="badge badge-gray">Disabled</span>
              </td>
              <td class="text-gray-300">{{ u.max_connections || 'Unlimited' }}</td>
              <td class="text-gray-400 text-xs">{{ u.expires_at ? new Date(u.expires_at).toLocaleDateString() : 'Never' }}</td>
              <td class="text-gray-500 font-mono text-xs max-w-[100px] truncate" :title="u.api_key">{{ u.api_key?.substring(0, 12) }}...</td>
              <td class="space-x-1">
                <button @click="openForm(u)" class="btn btn-secondary btn-sm">Edit</button>
                <button @click="regenKey(u)" class="btn btn-secondary btn-sm" title="Regenerate API Key">Key</button>
                <button @click="deleteUser(u)" class="btn btn-danger btn-sm">Del</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- User Form Modal -->
    <div v-if="showForm" class="fixed inset-0 bg-black/60 flex items-center justify-center z-50" @click.self="showForm = false">
      <div class="card w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <h3 class="text-lg font-bold text-white mb-4">{{ form.id ? 'Edit User' : 'Add User' }}</h3>
        <form @submit.prevent="saveUser" class="space-y-4">
          <div><label class="text-sm text-gray-300">Username *</label><input v-model="form.username" class="input-field mt-1" required /></div>
          <div><label class="text-sm text-gray-300">Email *</label><input v-model="form.email" type="email" class="input-field mt-1" required /></div>
          <div v-if="!form.id"><label class="text-sm text-gray-300">Password *</label><input v-model="form.password" type="password" class="input-field mt-1" required minlength="6" /></div>
          <div v-else><label class="text-sm text-gray-300">New Password (leave blank to keep)</label><input v-model="form.password" type="password" class="input-field mt-1" minlength="6" /></div>
          <div><label class="text-sm text-gray-300">Role</label>
            <select v-model="form.role" class="input-field mt-1"><option value="viewer">Viewer</option><option value="reseller">Reseller</option><option value="admin">Admin</option></select>
          </div>
          <div class="grid grid-cols-2 gap-4">
            <div><label class="text-sm text-gray-300">Max Connections</label><input v-model.number="form.max_connections" type="number" class="input-field mt-1" /></div>
            <div><label class="text-sm text-gray-300">Status</label>
              <select v-model="form.status" class="input-field mt-1"><option :value="true">Active</option><option :value="false">Disabled</option></select>
            </div>
          </div>
          <div class="flex items-center gap-2">
            <input type="checkbox" v-model="form.expirable" id="expirable" class="rounded" />
            <label for="expirable" class="text-sm text-gray-300">Has Expiration</label>
          </div>
          <div v-if="form.expirable"><label class="text-sm text-gray-300">Expires At</label><input v-model="form.expires_at" type="date" class="input-field mt-1" /></div>
          <div><label class="text-sm text-gray-300">Notes</label><textarea v-model="form.notes" class="input-field mt-1" rows="2"></textarea></div>
          <div class="flex gap-2 justify-end pt-2">
            <button type="button" @click="showForm = false" class="btn btn-secondary">Cancel</button>
            <button type="submit" class="btn btn-primary">{{ form.id ? 'Update' : 'Create' }}</button>
          </div>
        </form>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { adminApi } from '../api'

const users = ref([])
const showForm = ref(false)
const filters = ref({ search: '', role: '' })
const emptyForm = { id: null, username: '', email: '', password: '', role: 'viewer', status: true, max_connections: 1, expirable: false, expires_at: '', notes: '' }
const form = ref({ ...emptyForm })

onMounted(loadUsers)

async function loadUsers() {
  try { const res = await adminApi.getUsers(filters.value); users.value = res.data.data.data } catch {}
}

function openForm(u = null) { form.value = u ? { ...u, password: '' } : { ...emptyForm }; showForm.value = true }

async function saveUser() {
  try {
    if (form.value.id) await adminApi.updateUser(form.value.id, form.value)
    else await adminApi.createUser(form.value)
    showForm.value = false; loadUsers()
  } catch (err) { alert(err.response?.data?.message || 'Error') }
}

async function deleteUser(u) {
  if (!confirm(`Delete user "${u.username}"?`)) return
  try { await adminApi.deleteUser(u.id); loadUsers() } catch {}
}

async function regenKey(u) {
  if (!confirm(`Regenerate API key for "${u.username}"? The old key will stop working.`)) return
  try {
    const res = await adminApi.regenerateApiKey(u.id)
    prompt('New API Key (copy it now):', res.data.data.api_key)
    loadUsers()
  } catch {}
}
</script>