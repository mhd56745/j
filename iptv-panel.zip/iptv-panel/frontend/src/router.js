import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('./components/Login.vue'),
  },
  {
    path: '/',
    component: () => import('./components/DashboardLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      { path: '', name: 'Dashboard', component: () => import('./components/Dashboard.vue') },
      { path: 'channels', name: 'Channels', component: () => import('./components/ChannelManager.vue') },
      { path: 'streams', name: 'Streams', component: () => import('./components/StreamManager.vue') },
      { path: 'servers', name: 'Servers', component: () => import('./components/ServerManager.vue') },
      { path: 'users', name: 'Users', component: () => import('./components/UserManager.vue') },
      { path: 'player/:id?', name: 'Player', component: () => import('./components/Player.vue') },
    ],
  },
]

const router = createRouter({
  history: createWebHistory(),
  routes,
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('iptv_token')
  if (to.meta.requiresAuth && !token) {
    next('/login')
  } else {
    next()
  }
})

export default router