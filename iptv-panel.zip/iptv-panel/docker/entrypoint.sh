#!/bin/bash
set -e

echo "=========================================="
echo "  IPTV Panel - Startup"
echo "=========================================="

# Copy env file if not exists
if [ ! -f /app/backend/.env ]; then
    cp /app/.env.example /app/backend/.env
    echo "Created .env from .env.example"
fi

# Generate app key if not set
if ! grep -q "APP_KEY=base64:" /app/backend/.env || grep -q "APP_KEY=base64:$" /app/backend/.env; then
    cd /app/backend && php artisan key:generate --force
    echo "Generated APP_KEY"
fi

# Run migrations
cd /app/backend
php artisan migrate --force
echo "Database migrations complete"

# Ensure directories
mkdir -p /app/storage/app/hls
mkdir -p /app/storage/app/recordings
mkdir -p /app/storage/logs
chown -R www-data:www-data /app/storage

# Cache config
php artisan config:cache
php artisan route:cache

echo "=========================================="
echo "  Starting services..."
echo "=========================================="

# Start Supervisor (manages nginx, php-fpm, queue workers)
exec /usr/bin/supervisord -c /etc/supervisor/supervisord.conf