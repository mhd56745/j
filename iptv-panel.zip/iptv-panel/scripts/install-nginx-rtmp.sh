#!/bin/bash
# ============================================
# Install Nginx with RTMP Module from Source
# ============================================
# Use this if your distro doesn't have
# libnginx-mod-rtmp available.
# ============================================

set -e

NGINX_VERSION="1.24.0"
NGINX_RTMP_VERSION="1.2.2"
INSTALL_DIR="/usr/local/nginx"

echo "Building Nginx ${NGINX_VERSION} with RTMP module..."

# Install build dependencies
apt-get update -y
apt-get install -y build-essential libpcre3-dev zlib1g-dev libssl-dev wget

# Download sources
cd /tmp
wget -q "https://nginx.org/download/nginx-${NGINX_VERSION}.tar.gz"
wget -q "https://github.com/arut/nginx-rtmp-module/archive/refs/tags/v${NGINX_RTMP_VERSION}.tar.gz"

tar xzf "nginx-${NGINX_VERSION}.tar.gz"
tar xzf "v${NGINX_RTMP_VERSION}.tar.gz"

# Build
cd "nginx-${NGINX_VERSION}"
./configure \
    --prefix="${INSTALL_DIR}" \
    --with-http_ssl_module \
    --with-http_v2_module \
    --with-http_realip_module \
    --with-http_gzip_static_module \
    --add-module=../nginx-rtmp-module-${NGINX_RTMP_VERSION}

make -j$(nproc)
make install

# Cleanup
cd /
rm -rf /tmp/nginx-* /tmp/v*

# Verify
echo ""
echo "Nginx installed to ${INSTALL_DIR}"
echo "RTMP module: $(ls ${INSTALL_DIR}/modules/ngx_rtmp_module.so 2>/dev/null && echo 'OK' || echo 'Not found')"
echo ""
echo "Test: ${INSTALL_DIR}/sbin/nginx -t"