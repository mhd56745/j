#!/bin/bash
# ============================================
# IPTV Panel - Full Server Setup Script
# ============================================
# Run this on a fresh Ubuntu 22.04 server to
# install all dependencies and configure the
# IPTV panel with Nginx RTMP.
# ============================================

set -e

echo "=========================================="
echo "  IPTV Panel - Server Setup"
echo "  OS: Ubuntu 22.04 LTS"
echo "=========================================="

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC} $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 1. Update system
info "Updating system packages..."
apt-get update -y
apt-get upgrade -y

# 2. Install Nginx with RTMP module
info "Installing Nginx with RTMP module..."
apt-get install -y nginx libnginx-mod-rtmp

# 3. Install PHP 8.3 (using PPA)
info "Installing PHP 8.3..."
apt-get install -y software-properties-common
add-apt-repository -y ppa:ondrej/php
apt-get update -y
apt-get install -y php8.3-fpm php8.3-cli php8.3-common \
    php8.3-mysql php8.3-mbstring php8.3-xml php8.3-bcmath \
    php8.3-curl php8.3-zip php8.3-gd php8.3-intl \
    php8.3-readline php8.3-redis php8.3-sqlite3

# 4. Install FFmpeg (critical for restreaming)
info "Installing FFmpeg..."
apt-get install -y ffmpeg

# 5. Install Node.js 20
info "Installing Node.js..."
curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
apt-get install -y nodejs

# 6. Install Composer
info "Installing Composer..."
curl -sS https://getcomposer.org/installer | php -- --install-dir=/usr/local/bin --filename=composer

# 7. Install MySQL Client
info "Installing MySQL client..."
apt-get install -y mysql-client

# 8. Install Supervisor (for process management)
info "Installing Supervisor..."
apt-get install -y supervisor

# 9. Configure PHP
info "Configuring PHP-FPM..."
PHP_INI=/etc/php/8.3/fpm/php.ini
sed -i 's/upload_max_filesize = 2M/upload_max_filesize = 100M/' $PHP_INI
sed -i 's/post_max_size = 8M/post_max_size = 100M/' $PHP_INI
sed -i 's/max_execution_time = 30/max_execution_time = 3600/' $PHP_INI
sed -i 's/memory_limit = 128M/memory_limit = 512M/' $PHP_INI

# 10. Configure Nginx
info "Configuring Nginx with RTMP..."
cp nginx/nginx.conf /etc/nginx/nginx.conf

# 11. Setup application directories
info "Creating application directories..."
mkdir -p /app/storage/app/{hls,recordings,vod}
mkdir -p /app/storage/framework/{cache,sessions,views}
mkdir -p /app/storage/logs
chown -R www-data:www-data /app/storage
chmod -R 775 /app/storage

# 12. Install backend dependencies
info "Installing PHP dependencies..."
cd backend
composer install --no-dev --optimize-autoloader --no-interaction

# 13. Install and build frontend
info "Building frontend..."
cd ../frontend
npm install
npm run build
cd ..

# 14. Setup environment
if [ ! -f backend/.env ]; then
    cp .env.example backend/.env
    info "Created .env file - please configure it!"
fi

# 15. Generate app key
cd backend
php artisan key:generate --force

# 16. Setup Supervisor
info "Configuring Supervisor..."
cp docker/supervisord.conf /etc/supervisor/conf.d/iptv-panel.conf
supervisorctl reread
supervisorctl update

# 17. Restart services
info "Restarting services..."
service php8.3-fpm restart
service nginx restart
supervisorctl restart all

echo ""
echo "=========================================="
echo -e "${GREEN}  IPTV Panel Setup Complete!${NC}"
echo "=========================================="
echo ""
echo "Next steps:"
echo "  1. Edit backend/.env with your database credentials"
echo "  2. Run: cd backend && php artisan migrate --seed"
echo "  3. Start services: supervisorctl start all"
echo "  4. Access: http://YOUR_SERVER_IP"
echo "  5. RTMP: rtmp://YOUR_SERVER_IP:1935/live"
echo "  6. HLS: http://YOUR_SERVER_IP:8080/hls"
echo ""
echo "Default admin: admin@iptv.local / admin123"
echo "=========================================="