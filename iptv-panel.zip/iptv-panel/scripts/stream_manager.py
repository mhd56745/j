#!/usr/bin/env python3
"""
IPTV Stream Manager - Python utility for managing FFmpeg restream processes.

Usage:
    python stream_manager.py start --channel-id 1
    python stream_manager.py stop --stream-id 5
    python stream_manager.py list
    python stream_manager.py status
"""

import subprocess
import json
import os
import sys
import signal
import time
import argparse
import requests
from pathlib import Path

API_BASE = os.getenv('IPTV_API_URL', 'http://localhost:8000/api')
API_TOKEN = os.getenv('IPTV_API_TOKEN', '')
HLS_PATH = os.getenv('HLS_PATH', '/app/storage/app/hls')

HEADERS = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
}
if API_TOKEN:
    HEADERS['Authorization'] = f'Bearer {API_TOKEN}'


def api_get(path, params=None):
    r = requests.get(f'{API_BASE}{path}', headers=HEADERS, params=params, timeout=10)
    r.raise_for_status()
    return r.json()


def api_post(path, data=None):
    r = requests.post(f'{API_BASE}{path}', headers=HEADERS, json=data, timeout=30)
    r.raise_for_status()
    return r.json()


def start_restream(channel_id, server_id=None):
    """Start restreaming a channel via the API."""
    print(f"Starting restream for channel {channel_id}...")
    data = {'channel_id': channel_id}
    if server_id:
        data['server_id'] = server_id
    result = api_post('/admin/streams/restream', data)
    print(f"  Stream ID: {result['data']['id']}")
    print(f"  Stream Key: {result['data']['stream_key']}")
    print(f"  Status: {result['data']['status']}")
    return result['data']


def stop_stream(stream_id):
    """Stop a stream via the API."""
    print(f"Stopping stream {stream_id}...")
    result = api_post(f'/admin/streams/{stream_id}/stop')
    print(f"  Message: {result['message']}")
    return result


def list_streams(status=None):
    """List all streams."""
    params = {}
    if status:
        params['status'] = status
    result = api_get('/admin/streams', params)
    streams = result['data']['data']
    print(f"\n{'ID':<6} {'Channel':<25} {'Status':<12} {'Viewers':<8} {'Duration':<10}")
    print("-" * 65)
    for s in streams:
        ch = s.get('channel', {}).get('name', '-')
        print(f"{s['id']:<6} {ch:<25} {s['status']:<12} {s['viewer_count']:<8} {s.get('duration_formatted', '-'):<10}")
    print(f"\nTotal: {result['data']['total']} streams")
    return streams


def show_stats():
    """Show streaming statistics."""
    result = api_get('/admin/streams/stats')
    d = result['data']
    print("\n=== IPTV Stream Statistics ===")
    print(f"  Active Streams:   {d['active_streams']}")
    print(f"  Total Viewers:    {d['total_viewers']}")
    print(f"  Peak Viewers:     {d['peak_viewers']}")
    print(f"  Online Channels:  {d['online_channels']}/{d['total_channels']}")
    print(f"  Recent Errors:    {d['recent_errors']}")
    print("\n  Servers:")
    for srv in d['servers']:
        print(f"    {srv['name']}: {srv['connections']}/{srv['max_connections']} ({srv['load_percent']}%)")


def ffmpeg_restream_direct(source_url, stream_key, rtmp_host='localhost', rtmp_port=1935):
    """Launch FFmpeg restream directly (without API)."""
    hls_dir = os.path.join(HLS_PATH, stream_key)
    os.makedirs(hls_dir, exist_ok=True)

    cmd = [
        'ffmpeg', '-hide_banner', '-loglevel', 'warning',
        '-re', '-fflags', '+genpts',
        '-timeout', '30', '-reconnect', '1',
        '-reconnect_streamed', '1', '-reconnect_delay_max', '5',
        '-i', source_url,
        '-c:v', 'copy', '-c:a', 'aac', '-ar', '44100', '-ac', '2',
        '-f', 'flv', f'rtmp://{rtmp_host}:{rtmp_port}/live/{stream_key}',
        '-hls_time', '2', '-hls_list_size', '3',
        '-hls_flags', 'delete_segments',
        '-hls_segment_filename', f'{hls_dir}/seg_%03d.ts',
        f'{hls_dir}/index.m3u8',
    ]

    print(f"Launching: {' '.join(cmd)}")
    proc = subprocess.Popen(cmd)
    print(f"FFmpeg PID: {proc.pid}")
    return proc


def cleanup_hls(max_age_hours=24):
    """Remove old HLS segments."""
    import glob
    from datetime import datetime, timedelta

    cutoff = time.time() - (max_age_hours * 3600)
    count = 0
    for segment in glob.glob(os.path.join(HLS_PATH, '**/*.ts'), recursive=True):
        if os.path.getmtime(segment) < cutoff:
            os.remove(segment)
            count += 1
    for playlist in glob.glob(os.path.join(HLS_PATH, '**/*.m3u8'), recursive=True):
        if os.path.getmtime(playlist) < cutoff:
            os.remove(playlist)
            count += 1
    print(f"Cleaned up {count} old HLS files")


def main():
    parser = argparse.ArgumentParser(description='IPTV Stream Manager')
    sub = parser.add_subparsers(dest='command')

    # Start
    p_start = sub.add_parser('start', help='Start restreaming a channel')
    p_start.add_argument('--channel-id', type=int, required=True)
    p_start.add_argument('--server-id', type=int, default=None)

    # Stop
    p_stop = sub.add_parser('stop', help='Stop a stream')
    p_stop.add_argument('--stream-id', type=int, required=True)

    # List
    p_list = sub.add_parser('list', help='List streams')
    p_list.add_argument('--status', type=str, default=None)

    # Stats
    sub.add_parser('stats', help='Show statistics')

    # Cleanup
    p_clean = sub.add_parser('cleanup', help='Clean old HLS files')
    p_clean.add_argument('--max-age', type=int, default=24, help='Max age in hours')

    # Direct FFmpeg
    p_ffmpeg = sub.add_parser('ffmpeg', help='Direct FFmpeg restream')
    p_ffmpeg.add_argument('--source', type=str, required=True, help='Source stream URL')
    p_ffmpeg.add_argument('--key', type=str, required=True, help='Stream key')
    p_ffmpeg.add_argument('--host', type=str, default='localhost')

    args = parser.parse_args()

    if args.command == 'start':
        start_restream(args.channel_id, args.server_id)
    elif args.command == 'stop':
        stop_stream(args.stream_id)
    elif args.command == 'list':
        list_streams(args.status)
    elif args.command == 'stats':
        show_stats()
    elif args.command == 'cleanup':
        cleanup_hls(args.max_age)
    elif args.command == 'ffmpeg':
        ffmpeg_restream_direct(args.source, args.key, args.host)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()