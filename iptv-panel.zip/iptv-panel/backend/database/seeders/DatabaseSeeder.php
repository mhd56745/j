<?php

namespace Database\Seeders;

use App\Models\User;
use App\Models\Category;
use App\Models\Server;
use App\Models\Channel;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        // Create admin user
        User::create([
            'username' => 'admin',
            'email' => env('ADMIN_EMAIL', 'admin@iptv.local'),
            'password' => Hash::make(env('ADMIN_PASSWORD', 'admin123')),
            'role' => 'admin',
            'status' => true,
            'api_key' => 'admin_demo_api_key_change_me_in_production',
            'max_connections' => 0, // unlimited
        ]);

        // Create sample categories
        $categories = [
            ['name' => 'Sports', 'type' => 'live', 'sort_order' => 1],
            ['name' => 'News', 'type' => 'live', 'sort_order' => 2],
            ['name' => 'Entertainment', 'type' => 'live', 'sort_order' => 3],
            ['name' => 'Movies', 'type' => 'movie', 'sort_order' => 1],
            ['name' => 'Documentary', 'type' => 'live', 'sort_order' => 4],
            ['name' => 'Kids', 'type' => 'live', 'sort_order' => 5],
            ['name' => 'Music', 'type' => 'live', 'sort_order' => 6],
            ['name' => 'Series', 'type' => 'series', 'sort_order' => 1],
        ];

        foreach ($categories as $cat) {
            Category::create([
                'name' => $cat['name'],
                'slug' => \Illuminate\Support\Str::slug($cat['name']),
                'type' => $cat['type'],
                'sort_order' => $cat['sort_order'],
                'is_active' => true,
            ]);
        }

        // Create a default local server
        Server::create([
            'name' => 'Local Server',
            'hostname' => gethostname() ?: 'localhost',
            'ip_address' => '127.0.0.1',
            'rtmp_port' => 1935,
            'http_port' => 8080,
            'hls_port' => 8080,
            'max_connections' => 1000,
            'current_connections' => 0,
            'status' => 'online',
            'location' => 'Local',
        ]);

        // Create sample channels (with placeholder URLs)
        $sampleChannels = [
            ['name' => 'Sports HD 1', 'category' => 'Sports', 'url' => 'rtmp://example.com/live/sports1', 'format' => 'rtmp'],
            ['name' => 'Sports HD 2', 'category' => 'Sports', 'url' => 'https://example.com/stream/sports2.m3u8', 'format' => 'hls'],
            ['name' => 'News 24/7', 'category' => 'News', 'url' => 'https://example.com/stream/news.m3u8', 'format' => 'hls'],
            ['name' => 'Entertainment Plus', 'category' => 'Entertainment', 'url' => 'rtmp://example.com/live/ent1', 'format' => 'rtmp'],
            ['name' => 'Documentary World', 'category' => 'Documentary', 'url' => 'https://example.com/stream/docs.m3u8', 'format' => 'hls'],
            ['name' => 'Kids Zone', 'category' => 'Kids', 'url' => 'https://example.com/stream/kids.m3u8', 'format' => 'hls'],
            ['name' => 'Music TV', 'category' => 'Music', 'url' => 'rtmp://example.com/live/music', 'format' => 'rtmp'],
        ];

        foreach ($sampleChannels as $ch) {
            $category = Category::where('name', $ch['category'])->first();
            Channel::create([
                'name' => $ch['name'],
                'category_id' => $category?->id,
                'stream_source' => $ch['url'],
                'stream_type' => $category?->type ?? 'live',
                'stream_format' => $ch['format'],
                'is_active' => true,
                'is_restream' => true,
                'restream_url' => $ch['url'],
            ]);
        }

        // Create a sample viewer
        User::create([
            'username' => 'viewer1',
            'email' => 'viewer1@iptv.local',
            'password' => Hash::make('viewer123'),
            'role' => 'viewer',
            'status' => true,
            'api_key' => 'viewer_demo_api_key_change_me',
            'max_connections' => 1,
        ]);

        $this->command->info('IPTV Panel seeded successfully!');
        $this->command->info('Admin login: admin@iptv.local / admin123');
    }
}