<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('servers', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255);
            $table->string('hostname', 255);
            $table->string('ip_address', 45);
            $table->integer('rtmp_port')->default(1935);
            $table->integer('http_port')->default(8080);
            $table->integer('hls_port')->default(8080);
            $table->integer('max_connections')->default(1000);
            $table->integer('current_connections')->default(0);
            $table->enum('status', ['online', 'offline', 'maintenance'])->default('online');
            $table->string('location', 255)->nullable();
            $table->text('notes')->nullable();
            $table->string('health_check_url', 500)->nullable();
            $table->timestamp('last_health_check')->nullable();
            $table->timestamps();

            $table->index('status');
            $table->unique('ip_address');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('servers');
    }
};