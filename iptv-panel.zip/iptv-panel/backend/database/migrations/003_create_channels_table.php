<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('channels', function (Blueprint $table) {
            $table->id();
            $table->string('name', 255);
            $table->foreignId('category_id')->nullable()->constrained('categories')->nullOnDelete();
            $table->string('logo_url', 500)->nullable();
            $table->string('stream_source', 1000)->nullable();
            $table->enum('stream_type', ['live', 'movie', 'series'])->default('live');
            $table->enum('stream_format', ['rtmp', 'hls', 'http', 'm3u8'])->default('http');
            $table->string('epg_channel_id', 100)->nullable();
            $table->boolean('is_restream')->default(false);
            $table->string('restream_url', 1000)->nullable();
            $table->integer('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->string('quality', 50)->nullable();
            $table->integer('bitrate')->nullable();
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index('category_id');
            $table->index('stream_type');
            $table->index('is_active');
            $table->index('is_restream');
            $table->index('sort_order');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('channels');
    }
};