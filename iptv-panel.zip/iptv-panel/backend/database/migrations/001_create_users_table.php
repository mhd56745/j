<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            $table->string('username', 100)->unique();
            $table->string('email', 255)->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->string('api_key', 128)->unique()->nullable();
            $table->enum('role', ['admin', 'reseller', 'viewer'])->default('viewer');
            $table->boolean('status')->default(true);
            $table->integer('max_connections')->default(1);
            $table->boolean('expirable')->default(false);
            $table->timestamp('expires_at')->nullable();
            $table->text('notes')->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();

            $table->index('role');
            $table->index('status');
            $table->index('api_key');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('users');
    }
};