<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Streaming Configuration
    |--------------------------------------------------------------------------
    |
    | Configuration for RTMP/HLS streaming via Nginx RTMP module.
    |
    */

    // RTMP Server
    'rtmp_host' => env('RTMP_SERVER', 'localhost'),
    'rtmp_port' => (int) env('RTMP_PORT', 1935),
    'rtmp_app' => 'live',

    // HLS Settings
    'hls_path' => env('HLS_PATH', storage_path('app/hls')),
    'hls_url' => env('HLS_URL', '/hls'),
    'hls_fragment_duration' => (int) env('HLS_FRAGMENT_DURATION', 2),
    'hls_playlist_length' => (int) env('HLS_PLAYLIST_LENGTH', 3),
    'hls_cleanup' => true,
    'hls_nested' => false,

    // Stream Limits
    'max_concurrent_streams' => (int) env('MAX_CONCURRENT_STREAMS', 100),
    'stream_timeout' => (int) env('STREAM_TIMEOUT', 3600), // seconds
    'stream_key_length' => (int) env('STREAM_KEY_LENGTH', 16),

    // Restreaming
    'restream_timeout' => 30,
    'restream_retries' => 3,
    'restream_buffer_size' => 1024 * 1024, // 1MB

    // Recording
    'recording_enabled' => false,
    'recording_path' => storage_path('app/recordings'),
    'recording_format' => 'flv',

    // Statistics
    'stats_interval' => 10, // seconds
    'stats_retention_days' => 30,

    // Stream Protocols
    'protocols' => [
        'rtmp' => [
            'enabled' => true,
            'port' => 1935,
        ],
        'hls' => [
            'enabled' => true,
            'port' => 8080,
        ],
        'dash' => [
            'enabled' => false,
            'port' => 8081,
        ],
    ],

    // Nginx RTMP control
    'nginx_bin' => '/usr/sbin/nginx',
    'nginx_conf_path' => base_path('../nginx/nginx.conf'),
];