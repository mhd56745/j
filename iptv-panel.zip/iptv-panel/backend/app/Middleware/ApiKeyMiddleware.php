<?php

namespace App\Http\Middleware;

use App\Models\User;
use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class ApiKeyMiddleware
{
    /**
     * Authenticate via API key in the query string or header.
     * Used by streaming clients (VLC, Kodi, etc.) that cannot use Bearer tokens.
     */
    public function handle(Request $request, Closure $next): Response
    {
        $apiKey = $request->query('api_key')
            ?? $request->header('X-API-Key')
            ?? $request->header('Authorization');

        // Strip "Bearer " prefix if present
        if (str_starts_with($apiKey, 'Bearer ')) {
            $apiKey = substr($apiKey, 7);
        }

        if (!$apiKey) {
            return response()->json([
                'success' => false,
                'message' => 'API key is required.',
            ], 401);
        }

        $user = User::where('api_key', $apiKey)->active()->first();

        if (!$user) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired API key.',
            ], 401);
        }

        $request->setUserResolver(fn () => $user);

        return $next($request);
    }
}