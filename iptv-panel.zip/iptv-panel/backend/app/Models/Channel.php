<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Channel extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'category_id',
        'logo_url',
        'stream_source',
        'stream_type',     // 'live', 'movie', 'series'
        'stream_format',   // 'rtmp', 'hls', 'http', 'm3u8'
        'epg_channel_id',
        'is_restream',     // whether this is a restreamed channel
        'restream_url',
        'sort_order',
        'is_active',
        'quality',
        'bitrate',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'is_restream' => 'boolean',
            'sort_order' => 'integer',
            'bitrate' => 'integer',
        ];
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('is_active', true);
    }

    public function scopeLive($query)
    {
        return $query->where('stream_type', 'live');
    }

    public function scopeMovies($query)
    {
        return $query->where('stream_type', 'movie');
    }

    public function scopeSeries($query)
    {
        return $query->where('stream_type', 'series');
    }

    public function scopeRestream($query)
    {
        return $query->where('is_restream', true);
    }

    public function scopeOrdered($query)
    {
        return $query->orderBy('sort_order');
    }

    // Relationships
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function streams()
    {
        return $this->hasMany(Stream::class);
    }

    public function activeStream()
    {
        return $this->hasOne(Stream::class)->where('status', 'active');
    }

    public function server()
    {
        return $this->belongsTo(Server::class);
    }

    // Helpers
    public function getStreamUrl(): string
    {
        if ($this->is_restream && $this->restream_url) {
            return $this->restream_url;
        }
        if ($this->stream_format === 'rtmp') {
            $rtmpHost = config('streaming.rtmp_host');
            $rtmpPort = config('streaming.rtmp_port');
            $stream = $this->activeStream;
            if ($stream) {
                return "rtmp://{$rtmpHost}:{$rtmpPort}/live/{$stream->stream_key}";
            }
        }
        if ($this->stream_format === 'hls' || $this->stream_format === 'm3u8') {
            $stream = $this->activeStream;
            if ($stream) {
                return url(config('streaming.hls_url') . "/{$stream->stream_key}/index.m3u8");
            }
        }
        return $this->stream_source ?? '';
    }

    public function getHlsPlaylistUrl(): ?string
    {
        $stream = $this->activeStream;
        if ($stream) {
            return url(config('streaming.hls_url') . "/{$stream->stream_key}/index.m3u8");
        }
        return null;
    }

    public function getViewerCount(): int
    {
        return $this->streams()->where('status', 'active')->count();
    }

    public function isOnline(): bool
    {
        return $this->activeStream()->exists();
    }
}