<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'username',
        'email',
        'password',
        'role',
        'status',
        'max_connections',
        'expirable',
        'expires_at',
        'notes',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'password' => 'hashed',
            'email_verified_at' => 'datetime',
            'expires_at' => 'datetime',
            'status' => 'boolean',
            'expirable' => 'boolean',
            'max_connections' => 'integer',
        ];
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', true)
            ->where(function ($q) {
                $q->where('expirable', false)
                  ->orWhere('expires_at', '>', now());
            });
    }

    public function scopeAdmins($query)
    {
        return $query->where('role', 'admin');
    }

    public function scopeResellers($query)
    {
        return $query->where('role', 'reseller');
    }

    public function scopeViewers($query)
    {
        return $query->where('role', 'viewer');
    }

    // Relationships
    public function streamLogs()
    {
        return $this->hasMany(StreamLog::class);
    }

    public function activeStreams()
    {
        return $this->hasMany(Stream::class)->where('status', 'active');
    }

    // Helpers
    public function isAdmin(): bool
    {
        return $this->role === 'admin';
    }

    public function isReseller(): bool
    {
        return $this->role === 'reseller';
    }

    public function isExpired(): bool
    {
        return $this->expirable && $this->expires_at && $this->expires_at->isPast();
    }

    public function canConnect(): bool
    {
        if (!$this->status || $this->isExpired()) {
            return false;
        }
        if ($this->max_connections > 0) {
            return $this->activeStreams()->count() < $this->max_connections;
        }
        return true; // 0 = unlimited
    }
}