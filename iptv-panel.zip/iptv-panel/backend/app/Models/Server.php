<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Server extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'hostname',
        'ip_address',
        'rtmp_port',
        'http_port',
        'hls_port',
        'max_connections',
        'current_connections',
        'status',
        'location',
        'notes',
        'health_check_url',
        'last_health_check',
    ];

    protected function casts(): array
    {
        return [
            'rtmp_port' => 'integer',
            'http_port' => 'integer',
            'hls_port' => 'integer',
            'max_connections' => 'integer',
            'current_connections' => 'integer',
            'last_health_check' => 'datetime',
        ];
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'online');
    }

    // Relationships
    public function channels()
    {
        return $this->hasMany(Channel::class);
    }

    public function streams()
    {
        return $this->hasMany(Stream::class);
    }

    // Helpers
    public function getLoadPercentage(): float
    {
        if ($this->max_connections <= 0) {
            return 0;
        }
        return round(($this->current_connections / $this->max_connections) * 100, 2);
    }

    public function hasCapacity(): bool
    {
        return $this->current_connections < $this->max_connections;
    }

    public function getRtmpUrl(): string
    {
        return "rtmp://{$this->ip_address}:{$this->rtmp_port}/live";
    }

    public function getHlsBaseUrl(): string
    {
        return "http://{$this->ip_address}:{$this->hls_port}/hls";
    }

    public function isHealthy(): bool
    {
        return $this->status === 'online';
    }
}