<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Stream extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'channel_id',
        'server_id',
        'stream_key',
        'status',          // 'starting', 'active', 'stopping', 'ended', 'error'
        'start_time',
        'end_time',
        'duration',
        'viewer_count',
        'peak_viewer_count',
        'bytes_in',
        'bytes_out',
        'client_ip',
        'user_agent',
        'error_message',
    ];

    protected static function booted(): void
    {
        static::creating(function (Stream $stream) {
            if (empty($stream->stream_key)) {
                $length = config('streaming.stream_key_length', 16);
                $stream->stream_key = Str::random($length);
            }
            if (empty($stream->start_time)) {
                $stream->start_time = now();
            }
        });

        static::updating(function (Stream $stream) {
            if ($stream->isDirty('status') && $stream->status === 'ended') {
                $stream->end_time = now();
                if ($stream->start_time) {
                    $stream->duration = $stream->start_time->diffInSeconds(now());
                }
            }
        });
    }

    protected function casts(): array
    {
        return [
            'start_time' => 'datetime',
            'end_time' => 'datetime',
            'duration' => 'integer',
            'viewer_count' => 'integer',
            'peak_viewer_count' => 'integer',
            'bytes_in' => 'integer',
            'bytes_out' => 'integer',
        ];
    }

    // Scopes
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeOnline($query)
    {
        return $query->whereIn('status', ['starting', 'active']);
    }

    // Relationships
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function channel()
    {
        return $this->belongsTo(Channel::class);
    }

    public function server()
    {
        return $this->belongsTo(Server::class);
    }

    public function logs()
    {
        return $this->hasMany(StreamLog::class);
    }

    // Helpers
    public function isActive(): bool
    {
        return in_array($this->status, ['starting', 'active']);
    }

    public function getDurationFormatted(): string
    {
        $seconds = $this->duration ?? ($this->start_time ? $this->start_time->diffInSeconds(now()) : 0);
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $secs = $seconds % 60;
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $secs);
    }

    public function getBytesInFormatted(): string
    {
        return $this->formatBytes($this->bytes_in);
    }

    public function getBytesOutFormatted(): string
    {
        return $this->formatBytes($this->bytes_out);
    }

    private function formatBytes(?int $bytes): string
    {
        if ($bytes === null) return '0 B';
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }

    public function getHlsUrl(): string
    {
        return url(config('streaming.hls_url') . "/{$this->stream_key}/index.m3u8");
    }

    public function getRtmpUrl(): string
    {
        $host = $this->server->ip_address ?? config('streaming.rtmp_host');
        $port = $this->server->rtmp_port ?? config('streaming.rtmp_port');
        return "rtmp://{$host}:{$port}/live/{$this->stream_key}";
    }
}