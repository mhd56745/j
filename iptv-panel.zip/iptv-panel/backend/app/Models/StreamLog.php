<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StreamLog extends Model
{
    use HasFactory;

    protected $fillable = [
        'stream_id',
        'user_id',
        'channel_id',
        'event',        // 'start', 'stop', 'error', 'viewer_join', 'viewer_leave', 'restream_start', 'restream_stop'
        'message',
        'metadata',     // JSON - extra data about the event
        'ip_address',
        'user_agent',
    ];

    protected function casts(): array
    {
        return [
            'metadata' => 'array',
        ];
    }

    // Relationships
    public function stream()
    {
        return $this->belongsTo(Stream::class);
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function channel()
    {
        return $this->belongsTo(Channel::class);
    }

    // Scopes
    public function scopeErrors($query)
    {
        return $query->where('event', 'error');
    }

    public function scopeRecent($query, int $hours = 24)
    {
        return $query->where('created_at', '>=', now()->subHours($hours));
    }

    // Helpers
    public static function logEvent(Stream $stream, string $event, string $message = '', array $metadata = []): self
    {
        return self::create([
            'stream_id' => $stream->id,
            'user_id' => $stream->user_id,
            'channel_id' => $stream->channel_id,
            'event' => $event,
            'message' => $message,
            'metadata' => $metadata,
            'ip_address' => request()->ip(),
            'user_agent' => request()->userAgent(),
        ]);
    }
}