<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Ensure HLS storage directory exists
        $hlsPath = config('streaming.hls_path', storage_path('app/hls'));
        if (!is_dir($hlsPath)) {
            mkdir($hlsPath, 0755, true);
        }
    }
}