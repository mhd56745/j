<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Channel;
use App\Models\Stream;
use App\Models\User;
use App\Models\Server;
use App\Models\Category;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    /**
     * Get dashboard overview stats.
     */
    public function index()
    {
        // Channel stats
        $totalChannels = Channel::count();
        $activeChannels = Channel::whereHas('activeStream')->count();
        $liveChannels = Channel::live()->count();
        $restreamChannels = Channel::restream()->count();

        // Stream stats
        $activeStreams = Stream::active()->count();
        $totalViewers = Stream::active()->sum('viewer_count');
        $peakViewersToday = Stream::whereDate('created_at', today())
            ->max('peak_viewer_count') ?? 0;

        // User stats
        $totalUsers = User::count();
        $activeUsers = User::active()->count();
        $onlineViewers = User::viewers()
            ->active()
            ->whereHas('activeStreams')
            ->count();

        // Server stats
        $servers = Server::withCount(['streams' => fn ($q) => $q->online()])
            ->get()
            ->map(fn ($s) => [
                'id' => $s->id,
                'name' => $s->name,
                'status' => $s->status,
                'location' => $s->location,
                'active_streams' => $s->streams_count,
                'current_connections' => $s->current_connections,
                'max_connections' => $s->max_connections,
                'load_percent' => $s->getLoadPercentage(),
            ]);

        // Recent streams
        $recentStreams = Stream::with(['channel', 'user', 'server'])
            ->orderBy('created_at', 'desc')
            ->limit(10)
            ->get()
            ->map(fn ($s) => [
                'id' => $s->id,
                'channel' => $s->channel?->name,
                'user' => $s->user?->username,
                'server' => $s->server?->name,
                'status' => $s->status,
                'viewer_count' => $s->viewer_count,
                'duration_formatted' => $s->getDurationFormatted(),
                'created_at' => $s->created_at->toISOString(),
            ]);

        // Category distribution
        $categoryStats = Category::withCount(['channels' => fn ($q) => $q->where('is_active', true)])
            ->active()
            ->ordered()
            ->get()
            ->map(fn ($c) => [
                'name' => $c->name,
                'type' => $c->type,
                'channel_count' => $c->channels_count,
            ]);

        // Bandwidth estimate (bytes_out from active streams)
        $totalBytesOut = Stream::active()->sum('bytes_out');

        return response()->json([
            'success' => true,
            'data' => [
                'channels' => [
                    'total' => $totalChannels,
                    'active' => $activeChannels,
                    'live' => $liveChannels,
                    'restream' => $restreamChannels,
                ],
                'streams' => [
                    'active' => $activeStreams,
                    'total_viewers' => $totalViewers,
                    'peak_viewers_today' => $peakViewersToday,
                ],
                'users' => [
                    'total' => $totalUsers,
                    'active' => $activeUsers,
                    'online_viewers' => $onlineViewers,
                ],
                'servers' => $servers,
                'recent_streams' => $recentStreams,
                'category_distribution' => $categoryStats,
                'bandwidth' => [
                    'bytes_out' => $totalBytesOut,
                    'formatted' => $this->formatBytes($totalBytesOut),
                ],
            ],
        ]);
    }

    private function formatBytes(int $bytes): string
    {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $i = 0;
        while ($bytes >= 1024 && $i < count($units) - 1) {
            $bytes /= 1024;
            $i++;
        }
        return round($bytes, 2) . ' ' . $units[$i];
    }
}