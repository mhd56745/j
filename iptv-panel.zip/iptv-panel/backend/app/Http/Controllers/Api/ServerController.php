<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Server;
use App\Http\Requests\StoreServerRequest;
use Illuminate\Http\Request;

class ServerController extends Controller
{
    /**
     * List all streaming servers.
     */
    public function index(Request $request)
    {
        $query = Server::withCount(['channels', 'streams' => fn ($q) => $q->online()]);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }

        $servers = $query->orderBy('name')->paginate($request->get('per_page', 50));

        $servers->transform(function ($server) {
            $server->load_percent = $server->getLoadPercentage();
            $server->has_capacity = $server->hasCapacity();
            return $server;
        });

        return response()->json([
            'success' => true,
            'data' => $servers,
        ]);
    }

    /**
     * Store a new server.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'hostname' => 'required|string|max:255',
            'ip_address' => 'required|ip',
            'rtmp_port' => 'integer|default:1935',
            'http_port' => 'integer|default:8080',
            'hls_port' => 'integer|default:8080',
            'max_connections' => 'integer|default:1000',
            'location' => 'nullable|string|max:255',
            'notes' => 'nullable|string',
        ]);

        $server = Server::create(array_merge($validated, [
            'status' => 'online',
            'current_connections' => 0,
        ]));

        return response()->json([
            'success' => true,
            'data' => $server,
            'message' => 'Server added successfully.',
        ], 201);
    }

    /**
     * Show server details.
     */
    public function show(Server $server)
    {
        $server->load(['channels', 'streams' => fn ($q) => $q->online()]);
        $server->load_count = $server->getLoadPercentage();
        $server->has_capacity = $server->hasCapacity();

        return response()->json([
            'success' => true,
            'data' => $server,
        ]);
    }

    /**
     * Update a server.
     */
    public function update(Request $request, Server $server)
    {
        $validated = $request->validate([
            'name' => 'string|max:255',
            'hostname' => 'string|max:255',
            'ip_address' => 'ip',
            'rtmp_port' => 'integer',
            'http_port' => 'integer',
            'hls_port' => 'integer',
            'max_connections' => 'integer',
            'location' => 'nullable|string|max:255',
            'status' => 'in:online,offline,maintenance',
            'notes' => 'nullable|string',
        ]);

        $server->update($validated);

        return response()->json([
            'success' => true,
            'data' => $server,
            'message' => 'Server updated successfully.',
        ]);
    }

    /**
     * Delete a server.
     */
    public function destroy(Server $server)
    {
        // Move streams to another server or stop them
        $activeStreams = $server->streams()->online()->count();
        if ($activeStreams > 0) {
            return response()->json([
                'success' => false,
                'message' => "Cannot delete server with {$activeStreams} active streams. Stop them first.",
            ], 422);
        }

        $server->delete();

        return response()->json([
            'success' => true,
            'message' => 'Server deleted successfully.',
        ]);
    }

    /**
     * Health check a server.
     */
    public function healthCheck(Server $server)
    {
        try {
            $response = Http::timeout(5)->get("http://{$server->ip_address}:{$server->http_port}/stat");

            $isHealthy = $response->successful();
            $server->update([
                'status' => $isHealthy ? 'online' : 'offline',
                'last_health_check' => now(),
            ]);

            return response()->json([
                'success' => true,
                'data' => [
                    'status' => $server->status,
                    'response_time_ms' => $response->handlerStats()[0]['total_time'] ?? 0,
                    'is_healthy' => $isHealthy,
                ],
            ]);
        } catch (\Exception $e) {
            $server->update([
                'status' => 'offline',
                'last_health_check' => now(),
            ]);

            return response()->json([
                'success' => false,
                'data' => [
                    'status' => 'offline',
                    'error' => $e->getMessage(),
                ],
            ]);
        }
    }

    /**
     * Get Nginx RTMP stats from a server.
     */
    public function rtmpStats(Server $server)
    {
        try {
            $response = Http::timeout(5)->get("http://{$server->ip_address}:{$server->http_port}/stat");

            if ($response->successful()) {
                // Parse the XML stats from Nginx RTMP module
                $xml = simplexml_load_string($response->body());
                $stats = json_decode(json_encode($xml), true);

                // Update current connections
                $connections = $stats['server']['@attributes']['nconnections'] ?? 0;
                $server->update(['current_connections' => (int) $connections]);

                return response()->json([
                    'success' => true,
                    'data' => $stats,
                ]);
            }

            return response()->json([
                'success' => false,
                'message' => 'Unable to fetch RTMP stats.',
            ], 503);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => $e->getMessage(),
            ], 503);
        }
    }
}