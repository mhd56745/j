<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Stream;
use App\Models\StreamLog;
use App\Models\Channel;
use App\Models\Server;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class StreamController extends Controller
{
    /**
     * List all streams with filters.
     */
    public function index(Request $request)
    {
        $query = Stream::with(['user', 'channel', 'server']);

        if ($request->filled('status')) {
            $query->where('status', $request->status);
        }
        if ($request->filled('user_id')) {
            $query->where('user_id', $request->user_id);
        }
        if ($request->filled('channel_id')) {
            $query->where('channel_id', $request->channel_id);
        }
        if ($request->filled('server_id')) {
            $query->where('server_id', $request->server_id);
        }

        $perPage = $request->get('per_page', 50);
        $streams = $query->orderBy('created_at', 'desc')->paginate($perPage);

        $streams->transform(function ($stream) {
            $stream->duration_formatted = $stream->getDurationFormatted();
            $stream->bytes_in_formatted = $stream->getBytesInFormatted();
            $stream->bytes_out_formatted = $stream->getBytesOutFormatted();
            $stream->hls_url = $stream->getHlsUrl();
            return $stream;
        });

        return response()->json([
            'success' => true,
            'data' => $streams,
        ]);
    }

    /**
     * Start a restream for a channel.
     * Pulls from source URL and pushes to local RTMP server.
     */
    public function startRestream(Request $request)
    {
        $validated = $request->validate([
            'channel_id' => 'required|exists:channels,id',
            'server_id' => 'nullable|exists:servers,id',
        ]);

        $channel = Channel::findOrFail($validated['channel_id']);

        if (!$channel->stream_source && !$channel->restream_url) {
            return response()->json([
                'success' => false,
                'message' => 'Channel has no stream source configured.',
            ], 422);
        }

        // Check for existing active stream
        $existingStream = Stream::where('channel_id', $channel->id)
            ->online()
            ->first();

        if ($existingStream) {
            return response()->json([
                'success' => false,
                'message' => 'Channel already has an active stream.',
                'data' => $existingStream,
            ], 409);
        }

        // Select server
        $server = null;
        if (!empty($validated['server_id'])) {
            $server = Server::findOrFail($validated['server_id']);
        } else {
            $server = Server::active()
                ->whereHasCapacity()
                ->orderBy('current_connections')
                ->first();
        }

        // Create stream record
        $stream = Stream::create([
            'user_id' => $request->user()?->id,
            'channel_id' => $channel->id,
            'server_id' => $server?->id,
            'status' => 'starting',
            'client_ip' => $request->ip(),
            'user_agent' => $request->userAgent(),
        ]);

        StreamLog::logEvent($stream, 'restream_start', "Starting restream for channel: {$channel->name}");

        // Launch FFmpeg restream process
        $this->launchRestreamProcess($stream, $channel, $server);

        return response()->json([
            'success' => true,
            'data' => $stream,
            'message' => 'Restream process started.',
        ], 201);
    }

    /**
     * Stop a stream.
     */
    public function stop(Request $request, Stream $stream)
    {
        if (!$stream->isActive()) {
            return response()->json([
                'success' => false,
                'message' => 'Stream is not active.',
            ], 400);
        }

        $stream->update(['status' => 'stopping']);
        StreamLog::logEvent($stream, 'stop', 'Stream stop requested by admin');

        // Kill FFmpeg process
        $this->killStreamProcess($stream);

        $stream->update([
            'status' => 'ended',
            'end_time' => now(),
            'duration' => $stream->start_time->diffInSeconds(now()),
        ]);

        StreamLog::logEvent($stream, 'stop', 'Stream ended successfully');

        return response()->json([
            'success' => true,
            'message' => 'Stream stopped successfully.',
        ]);
    }

    /**
     * Get stream statistics.
     */
    public function stats()
    {
        $totalActive = Stream::active()->count();
        $totalViewers = Stream::active()->sum('viewer_count');
        $peakViewers = Stream::active()->sum('peak_viewer_count');

        $byStatus = Stream::selectRaw('status, count(*) as count')
            ->groupBy('status')
            ->pluck('count', 'status');

        $recentErrors = StreamLog::errors()->recent(1)->count();

        $onlineChannels = Channel::whereHas('activeStream')->count();
        $totalChannels = Channel::count();

        $servers = Server::active()->get()->map(fn ($s) => [
            'name' => $s->name,
            'connections' => $s->current_connections,
            'max_connections' => $s->max_connections,
            'load_percent' => $s->getLoadPercentage(),
        ]);

        return response()->json([
            'success' => true,
            'data' => [
                'active_streams' => $totalActive,
                'total_viewers' => $totalViewers,
                'peak_viewers' => $peakViewers,
                'online_channels' => $onlineChannels,
                'total_channels' => $totalChannels,
                'streams_by_status' => $byStatus,
                'recent_errors' => $recentErrors,
                'servers' => $servers,
            ],
        ]);
    }

    /**
     * Get stream logs.
     */
    public function logs(Request $request)
    {
        $query = StreamLog::with(['stream', 'user', 'channel']);

        if ($request->filled('stream_id')) {
            $query->where('stream_id', $request->stream_id);
        }
        if ($request->filled('event')) {
            $query->where('event', $request->event);
        }
        if ($request->filled('channel_id')) {
            $query->where('channel_id', $request->channel_id);
        }

        $logs = $query->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 50));

        return response()->json([
            'success' => true,
            'data' => $logs,
        ]);
    }

    /**
     * RTMP publish callback - called by Nginx RTMP module on publish.
     */
    public function onPublish(Request $request)
    {
        $streamKey = $request->input('name');
        $app = $request->input('app');

        $stream = Stream::where('stream_key', $streamKey)
            ->whereIn('status', ['starting', 'active'])
            ->first();

        if (!$stream) {
            return response('denied', 403);
        }

        $stream->update([
            'status' => 'active',
            'client_ip' => $request->ip(),
        ]);

        StreamLog::logEvent($stream, 'start', 'Stream published to RTMP server');

        return response('ok', 200);
    }

    /**
     * RTMP publish done callback - called by Nginx RTMP module on stream end.
     */
    public function onPublishDone(Request $request)
    {
        $streamKey = $request->input('name');

        $stream = Stream::where('stream_key', $streamKey)->active()->first();
        if ($stream) {
            $stream->update([
                'status' => 'ended',
                'end_time' => now(),
                'duration' => $stream->start_time->diffInSeconds(now()),
            ]);
            StreamLog::logEvent($stream, 'stop', 'Stream unpublished from RTMP server');
        }

        return response('ok', 200);
    }

    /**
     * RTMP play callback - called when a viewer starts watching.
     */
    public function onPlay(Request $request)
    {
        $streamKey = $request->input('name');
        $stream = Stream::where('stream_key', $streamKey)->active()->first();

        if ($stream) {
            $stream->increment('viewer_count');
            if ($stream->viewer_count > $stream->peak_viewer_count) {
                $stream->update(['peak_viewer_count' => $stream->viewer_count]);
            }
        }

        return response('ok', 200);
    }

    /**
     * RTMP play done callback - called when a viewer stops watching.
     */
    public function onPlayDone(Request $request)
    {
        $streamKey = $request->input('name');
        $stream = Stream::where('stream_key', $streamKey)->active()->first();

        if ($stream && $stream->viewer_count > 0) {
            $stream->decrement('viewer_count');
        }

        return response('ok', 200);
    }

    /**
     * Launch FFmpeg to restream from source to local RTMP.
     */
    private function launchRestreamProcess(Stream $stream, Channel $channel, ?Server $server): void
    {
        $sourceUrl = $channel->restream_url ?? $channel->stream_source;
        $rtmpHost = $server?->ip_address ?? config('streaming.rtmp_host');
        $rtmpPort = $server?->rtmp_port ?? config('streaming.rtmp_port');
        $rtmpApp = config('streaming.rtmp_app', 'live');
        $hlsPath = config('streaming.hls_path');
        $fragDur = config('streaming.hls_fragment_duration', 2);
        $playlistLen = config('streaming.hls_playlist_length', 3);

        // Ensure HLS directory exists
        $streamHlsPath = "{$hlsPath}/{$stream->stream_key}";
        if (!is_dir($streamHlsPath)) {
            mkdir($streamHlsPath, 0755, true);
        }

        // FFmpeg command for restreaming
        $cmd = sprintf(
            'nohup ffmpeg -hide_banner -loglevel warning -re -fflags +genpts ' .
            '-timeout %d -reconnect 1 -reconnect_streamed 1 -reconnect_delay_max %d ' .
            '-i "%s" ' .
            '-c:v copy -c:a aac -ar 44100 -ac 2 ' .
            '-f flv "rtmp://%s:%d/%s/%s" ' .
            '-hls_time %d -hls_list_size %d -hls_flags delete_segments ' .
            '-hls_segment_filename "%s/seg_%%03d.ts" ' .
            '"%s/index.m3u8" ' .
            '> /dev/null 2>&1 & echo $!',
            config('streaming.restream_timeout', 30),
            config('streaming.restream_retries', 3),
            $sourceUrl,
            $rtmpHost,
            $rtmpPort,
            $rtmpApp,
            $stream->stream_key,
            $fragDur,
            $playlistLen,
            $streamHlsPath,
            $streamHlsPath
        );

        $pid = shell_exec($cmd);
        $stream->update(['metadata' => array_merge($stream->metadata ?? [], ['ffmpeg_pid' => trim($pid)])]);

        StreamLog::logEvent($stream, 'restream_start', "FFmpeg launched with PID: " . trim($pid), [
            'source' => $sourceUrl,
            'pid' => trim($pid),
        ]);
    }

    /**
     * Kill the FFmpeg process for a stream.
     */
    private function killStreamProcess(Stream $stream): void
    {
        $pid = $stream->metadata['ffmpeg_pid'] ?? null;
        if ($pid) {
            exec("kill -9 {$pid} 2>/dev/null");
        }
    }
}