<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Channel;
use App\Models\Stream;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    /**
     * Admin login - returns Sanctum token.
     */
    public function login(Request $request)
    {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        $user = User::where('email', $request->email)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'email' => ['The provided credentials are incorrect.'],
            ]);
        }

        if (!$user->isAdmin()) {
            throw ValidationException::withMessages([
                'email' => ['Admin access required.'],
            ]);
        }

        $token = $user->createToken('admin-token', ['admin'])->plainTextToken;

        return response()->json([
            'success' => true,
            'data' => [
                'user' => $user,
                'token' => $token,
                'token_type' => 'Bearer',
            ],
        ]);
    }

    /**
     * Logout - revoke current token.
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        return response()->json([
            'success' => true,
            'message' => 'Logged out successfully.',
        ]);
    }

    /**
     * Get current authenticated user.
     */
    public function me(Request $request)
    {
        return response()->json([
            'success' => true,
            'data' => $request->user(),
        ]);
    }

    /**
     * Generate API key for a user (admin only).
     */
    public function generateApiKey(Request $request, User $user)
    {
        $user->api_key = \Illuminate\Support\Str::random(64);
        $user->save();

        return response()->json([
            'success' => true,
            'data' => ['api_key' => $user->api_key],
        ]);
    }

    /**
     * Get IPTV playlist (M3U format) for a user.
     * Used by VLC, Kodi, TiviMate, etc.
     */
    public function getM3uPlaylist(Request $request)
    {
        $user = $request->user();
        $channels = Channel::active()
            ->with('category')
            ->ordered()
            ->get();

        $lines = ['#EXTM3U'];
        foreach ($channels as $channel) {
            $logo = $channel->logo_url ?? '';
            $group = $channel->category?->name ?? 'Uncategorized';
            $streamUrl = $channel->getStreamUrl();

            $lines[] = "#EXTINF:-1 tvg-id=\"{$channel->id}\" tvg-name=\"{$channel->name}\" tvg-logo=\"{$logo}\" group-title=\"{$group}\",{$channel->name}";
            $lines[] = $streamUrl;
        }

        return response($lines . "\n")
            ->header('Content-Type', 'application/x-mpegurl')
            ->header('Content-Disposition', 'attachment; filename="playlist.m3u"');
    }

    /**
     * Get XTREAM CODES API compatible endpoints.
     */
    public function xtreamAction(Request $request)
    {
        $user = $request->user();
        $action = $request->query('action');

        return match ($action) {
            'get_live_categories' => $this->getLiveCategories(),
            'get_live_streams' => $this->getLiveStreams($user),
            'get_vod_categories' => $this->getVodCategories(),
            'get_vod_streams' => $this->getVodStreams($user),
            default => response()->json(['success' => false, 'message' => 'Unknown action']),
        };
    }

    private function getLiveCategories()
    {
        $categories = Category::active()->live()->ordered()->get();
        return response()->json($categories->map(fn ($c) => [
            'category_id' => $c->id,
            'category_name' => $c->name,
            'parent_id' => $c->parent_id ?? 0,
        ]));
    }

    private function getLiveStreams($user)
    {
        $streams = Channel::active()->live()->with('category')->ordered()->get();
        return response()->json($streams->map(fn ($c) => [
            'num' => $c->id,
            'name' => $c->name,
            'stream_type' => 'live',
            'stream_id' => $c->id,
            'stream_icon' => $c->logo_url,
            'category_id' => $c->category_id,
            'custom_sid' => $user->api_key,
            'tv_archive' => 0,
            'direct_source' => $c->getStreamUrl(),
            'epg_channel_id' => $c->epg_channel_id,
        ]));
    }

    private function getVodCategories()
    {
        $categories = Category::active()->movies()->ordered()->get();
        return response()->json($categories->map(fn ($c) => [
            'category_id' => $c->id,
            'category_name' => $c->name,
            'parent_id' => $c->parent_id ?? 0,
        ]));
    }

    private function getVodStreams($user)
    {
        $streams = Channel::active()->movies()->with('category')->ordered()->get();
        return response()->json($streams->map(fn ($c) => [
            'num' => $c->id,
            'name' => $c->name,
            'stream_type' => 'movie',
            'stream_id' => $c->id,
            'stream_icon' => $c->logo_url,
            'category_id' => $c->category_id,
            'container_extension' => 'mp4',
            'custom_sid' => $user->api_key,
            'direct_source' => $c->stream_source,
        ]));
    }
}