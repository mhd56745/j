<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\User;
use App\Models\Stream;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    /**
     * List users with filters.
     */
    public function index(Request $request)
    {
        $query = User::withCount(['activeStreams', 'streamLogs']);

        if ($request->filled('role')) {
            $query->where('role', $request->role);
        }
        if ($request->filled('status')) {
            $query->where('status', $request->boolean('status'));
        }
        if ($request->filled('search')) {
            $query->where(function ($q) use ($request) {
                $q->where('username', 'like', '%' . $request->search . '%')
                  ->orWhere('email', 'like', '%' . $request->search . '%');
            });
        }

        $users = $query->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 50));

        $users->transform(function ($user) {
            $user->is_expired = $user->isExpired();
            $user->can_connect = $user->canConnect();
            return $user;
        });

        return response()->json([
            'success' => true,
            'data' => $users,
        ]);
    }

    /**
     * Create a new user.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'username' => 'required|string|max:100|unique:users',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|string|min:6',
            'role' => 'required|in:admin,reseller,viewer',
            'status' => 'boolean',
            'max_connections' => 'integer|default:1',
            'expirable' => 'boolean',
            'expires_at' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);

        $validated['password'] = Hash::make($validated['password']);
        $validated['api_key'] = \Illuminate\Support\Str::random(64);

        $user = User::create($validated);

        return response()->json([
            'success' => true,
            'data' => $user,
            'message' => 'User created successfully.',
        ], 201);
    }

    /**
     * Show user details.
     */
    public function show(User $user)
    {
        $user->load(['activeStreams', 'streamLogs' => fn ($q) => $q->recent(24)]);

        // Compute totals
        $totalStreams = Stream::where('user_id', $user->id)->count();
        $totalDuration = Stream::where('user_id', $user->id)
            ->whereNotNull('duration')
            ->sum('duration');

        return response()->json([
            'success' => true,
            'data' => [
                'user' => $user,
                'stats' => [
                    'total_streams' => $totalStreams,
                    'active_streams' => $user->activeStreams->count(),
                    'total_duration_seconds' => $totalDuration,
                    'total_duration_formatted' => $this->formatDuration($totalDuration),
                ],
            ],
        ]);
    }

    /**
     * Update user.
     */
    public function update(Request $request, User $user)
    {
        $validated = $request->validate([
            'username' => 'string|max:100',
            'email' => 'email|max:255',
            'password' => 'nullable|string|min:6',
            'role' => 'in:admin,reseller,viewer',
            'status' => 'boolean',
            'max_connections' => 'integer',
            'expirable' => 'boolean',
            'expires_at' => 'nullable|date',
            'notes' => 'nullable|string',
        ]);

        if (isset($validated['password'])) {
            $validated['password'] = Hash::make($validated['password']);
        }

        $user->update($validated);

        return response()->json([
            'success' => true,
            'data' => $user,
            'message' => 'User updated successfully.',
        ]);
    }

    /**
     * Delete user.
     */
    public function destroy(User $user)
    {
        // Stop active streams
        $user->activeStreams()->update([
            'status' => 'ended',
            'end_time' => now(),
        ]);

        $user->delete();

        return response()->json([
            'success' => true,
            'message' => 'User deleted successfully.',
        ]);
    }

    /**
     * Regenerate API key for a user.
     */
    public function regenerateApiKey(User $user)
    {
        $user->update(['api_key' => \Illuminate\Support\Str::random(64)]);

        return response()->json([
            'success' => true,
            'data' => ['api_key' => $user->api_key],
            'message' => 'API key regenerated.',
        ]);
    }

    /**
     * Bulk create users from CSV.
     */
    public function bulkCreate(Request $request)
    {
        $request->validate([
            'users' => 'required|array|min:1',
            'users.*.username' => 'required|string|max:100',
            'users.*.email' => 'required|email|max:255',
            'users.*.password' => 'required|string|min:6',
            'users.*.role' => 'required|in:admin,reseller,viewer',
            'max_connections' => 'nullable|integer',
            'expirable' => 'nullable|boolean',
            'expires_at' => 'nullable|date',
        ]);

        $created = 0;
        $errors = [];

        foreach ($request->users as $userData) {
            try {
                User::create([
                    'username' => $userData['username'],
                    'email' => $userData['email'],
                    'password' => Hash::make($userData['password']),
                    'role' => $userData['role'],
                    'api_key' => \Illuminate\Support\Str::random(64),
                    'status' => true,
                    'max_connections' => $request->max_connections ?? 1,
                    'expirable' => $request->expirable ?? false,
                    'expires_at' => $request->expires_at,
                ]);
                $created++;
            } catch (\Exception $e) {
                $errors[] = [
                    'username' => $userData['username'],
                    'error' => $e->getMessage(),
                ];
            }
        }

        return response()->json([
            'success' => true,
            'data' => [
                'created' => $created,
                'errors' => $errors,
            ],
        ]);
    }

    private function formatDuration(int $seconds): string
    {
        $hours = floor($seconds / 3600);
        $minutes = floor(($seconds % 3600) / 60);
        $secs = $seconds % 60;
        return sprintf('%02d:%02d:%02d', $hours, $minutes, $secs);
    }
}