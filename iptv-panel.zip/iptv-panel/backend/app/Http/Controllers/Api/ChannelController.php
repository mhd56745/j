<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Channel;
use App\Models\Stream;
use App\Models\StreamLog;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ChannelController extends Controller
{
    /**
     * List all channels with filters.
     */
    public function index(Request $request)
    {
        $query = Channel::with(['category', 'activeStream', 'server']);

        // Filters
        if ($request->filled('category_id')) {
            $query->where('category_id', $request->category_id);
        }
        if ($request->filled('type')) {
            $query->where('stream_type', $request->type);
        }
        if ($request->filled('status')) {
            if ($request->status === 'online') {
                $query->whereHas('activeStream');
            } elseif ($request->status === 'offline') {
                $query->whereDoesntHave('activeStream');
            }
        }
        if ($request->filled('search')) {
            $query->where('name', 'like', '%' . $request->search . '%');
        }
        if ($request->filled('is_restream')) {
            $query->where('is_restream', $request->boolean('is_restream'));
        }

        $sortBy = $request->get('sort_by', 'sort_order');
        $sortDir = $request->get('sort_dir', 'asc');
        $query->orderBy($sortBy, $sortDir);

        $perPage = $request->get('per_page', 50);
        $channels = $query->paginate($perPage);

        // Append stream status and URLs
        $channels->transform(function ($channel) {
            $channel->is_online = $channel->isOnline();
            $channel->hls_url = $channel->getHlsPlaylistUrl();
            $channel->stream_url = $channel->getStreamUrl();
            $channel->viewer_count = $channel->getViewerCount();
            return $channel;
        });

        return response()->json([
            'success' => true,
            'data' => $channels,
        ]);
    }

    /**
     * Store a new channel.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'logo_url' => 'nullable|url|max:500',
            'stream_source' => 'nullable|string|max:1000',
            'stream_type' => 'required|in:live,movie,series',
            'stream_format' => 'required|in:rtmp,hls,http,m3u8',
            'epg_channel_id' => 'nullable|string|max:100',
            'is_restream' => 'boolean',
            'restream_url' => 'nullable|url|max:1000',
            'sort_order' => 'integer',
            'is_active' => 'boolean',
            'quality' => 'nullable|string|max:50',
            'bitrate' => 'nullable|integer',
            'notes' => 'nullable|string',
        ]);

        $channel = Channel::create($validated);

        return response()->json([
            'success' => true,
            'data' => $channel,
            'message' => 'Channel created successfully.',
        ], 201);
    }

    /**
     * Show a single channel.
     */
    public function show(Channel $channel)
    {
        $channel->load(['category', 'streams', 'server']);
        $channel->is_online = $channel->isOnline();
        $channel->hls_url = $channel->getHlsPlaylistUrl();
        $channel->stream_url = $channel->getStreamUrl();
        $channel->viewer_count = $channel->getViewerCount();

        return response()->json([
            'success' => true,
            'data' => $channel,
        ]);
    }

    /**
     * Update a channel.
     */
    public function update(Request $request, Channel $channel)
    {
        $validated = $request->validate([
            'name' => 'string|max:255',
            'category_id' => 'nullable|exists:categories,id',
            'logo_url' => 'nullable|url|max:500',
            'stream_source' => 'nullable|string|max:1000',
            'stream_type' => 'in:live,movie,series',
            'stream_format' => 'in:rtmp,hls,http,m3u8',
            'epg_channel_id' => 'nullable|string|max:100',
            'is_restream' => 'boolean',
            'restream_url' => 'nullable|url|max:1000',
            'sort_order' => 'integer',
            'is_active' => 'boolean',
            'quality' => 'nullable|string|max:50',
            'bitrate' => 'nullable|integer',
            'notes' => 'nullable|string',
        ]);

        $channel->update($validated);

        return response()->json([
            'success' => true,
            'data' => $channel,
            'message' => 'Channel updated successfully.',
        ]);
    }

    /**
     * Delete a channel.
     */
    public function destroy(Channel $channel)
    {
        // Stop active streams for this channel
        $channel->streams()->online()->update([
            'status' => 'ended',
            'end_time' => now(),
        ]);

        $channel->delete();

        return response()->json([
            'success' => true,
            'message' => 'Channel deleted successfully.',
        ]);
    }

    /**
     * Bulk import channels from M3U file.
     */
    public function bulkImport(Request $request)
    {
        $request->validate([
            'file' => 'required|file|mimetypes:text/plain,application/octet-stream',
            'category_id' => 'nullable|exists:categories,id',
            'stream_type' => 'nullable|in:live,movie,series',
        ]);

        $file = $request->file('file');
        $content = file_get_contents($file->getRealPath());
        $lines = explode("\n", $content);

        $imported = 0;
        $errors = [];
        $categoryId = $request->category_id;
        $streamType = $request->get('stream_type', 'live');

        $i = 0;
        while ($i < count($lines)) {
            $line = trim($lines[$i]);

            if (str_starts_with($line, '#EXTINF:')) {
                // Parse channel name
                $name = 'Unknown Channel';
                $logoUrl = '';
                $group = '';

                if (preg_match('/,(.+)$/', $line, $matches)) {
                    $name = trim($matches[1]);
                }
                if (preg_match('/tvg-logo="([^"]+)"/', $line, $matches)) {
                    $logoUrl = $matches[1];
                }
                if (preg_match('/group-title="([^"]+)"/', $line, $matches)) {
                    $group = $matches[1];
                }

                // Next line should be the URL
                $i++;
                if (isset($lines[$i])) {
                    $url = trim($lines[$i]);
                    if (filter_var($url, FILTER_VALIDATE_URL)) {
                        // Find or create category
                        if ($group && !$categoryId) {
                            $cat = Category::firstOrCreate(
                                ['slug' => Str::slug($group)],
                                ['name' => $group, 'type' => $streamType, 'is_active' => true]
                            );
                            $categoryId = $cat->id;
                        }

                        $format = 'http';
                        if (str_starts_with($url, 'rtmp://')) $format = 'rtmp';
                        if (str_ends_with($url, '.m3u8')) $format = 'hls';

                        Channel::create([
                            'name' => $name,
                            'category_id' => $categoryId,
                            'logo_url' => $logoUrl,
                            'stream_source' => $url,
                            'stream_type' => $streamType,
                            'stream_format' => $format,
                            'is_active' => true,
                        ]);
                        $imported++;
                    }
                }
            }
            $i++;
        }

        return response()->json([
            'success' => true,
            'data' => [
                'imported' => $imported,
                'errors' => $errors,
            ],
            'message' => "Imported {$imported} channels.",
        ]);
    }

    /**
     * Export channels as M3U playlist.
     */
    public function exportM3u(Request $request)
    {
        $channels = Channel::active()
            ->with('category')
            ->when($request->filled('category_id'), fn ($q) => $q->where('category_id', $request->category_id))
            ->when($request->filled('type'), fn ($q) => $q->where('stream_type', $request->type))
            ->ordered()
            ->get();

        $lines = ['#EXTM3U'];
        foreach ($channels as $channel) {
            $logo = $channel->logo_url ?? '';
            $group = $channel->category?->name ?? 'Uncategorized';
            $streamUrl = $channel->is_restream ? $channel->restream_url : $channel->stream_source;

            $lines[] = "#EXTINF:-1 tvg-id=\"{$channel->id}\" tvg-name=\"{$channel->name}\" tvg-logo=\"{$logo}\" group-title=\"{$group}\",{$channel->name}";
            $lines[] = $streamUrl;
        }

        return response(implode("\n", $lines))
            ->header('Content-Type', 'audio/x-mpegurl')
            ->header('Content-Disposition', 'attachment; filename="channels.m3u"');
    }
}