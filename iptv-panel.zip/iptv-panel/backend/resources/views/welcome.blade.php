<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>IPTV Panel</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; background: #0a0a1a; color: #e0e0e0; display: flex; align-items: center; justify-content: center; min-height: 100vh; }
        .container { text-align: center; max-width: 600px; padding: 2rem; }
        h1 { font-size: 2rem; margin-bottom: 0.5rem; }
        p { color: #888; margin-bottom: 1.5rem; }
        a { color: #3b82f6; text-decoration: none; }
        a:hover { text-decoration: underline; }
        .badge { display: inline-block; background: #1e293b; border: 1px solid #334155; border-radius: 8px; padding: 1rem 2rem; margin: 0.5rem; }
    </style>
</head>
<body>
    <div class="container">
        <h1>IPTV Panel API</h1>
        <p>The admin panel is loading. If this page persists, please build the frontend.</p>
        <div class="badge"><a href="/api/admin/dashboard">Dashboard API</a></div>
        <div class="badge"><a href="/docs">API Documentation</a></div>
    </div>
</body>
</html>