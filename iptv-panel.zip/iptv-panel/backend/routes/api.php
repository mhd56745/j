<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\ChannelController;
use App\Http\Controllers\Api\StreamController;
use App\Http\Controllers\Api\ServerController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Admin\DashboardController;

/*
|--------------------------------------------------------------------------
| API Routes - IPTV Panel
|--------------------------------------------------------------------------
*/

// ===================== PUBLIC / AUTH =====================
Route::prefix('auth')->group(function () {
    Route::post('/login', [AuthController::class, 'login']);

    Route::middleware('auth:sanctum')->group(function () {
        Route::post('/logout', [AuthController::class, 'logout']);
        Route::get('/me', [AuthController::class, 'me']);
    });
});

// ===================== STREAM CALLBACKS (Nginx RTMP) =====================
Route::prefix('callbacks/rtmp')->group(function () {
    Route::post('/on_publish', [StreamController::class, 'onPublish']);
    Route::post('/on_publish_done', [StreamController::class, 'onPublishDone']);
    Route::post('/on_play', [StreamController::class, 'onPlay']);
    Route::post('/on_play_done', [StreamController::class, 'onPlayDone']);
});

// ===================== CLIENT API (API Key Auth) =====================
// Used by IPTV players (VLC, Kodi, TiviMate, etc.)
Route::middleware(\App\Http\Middleware\ApiKeyMiddleware::class)->group(function () {
    // M3U Playlist
    Route::get('/playlist.m3u', [AuthController::class, 'getM3uPlaylist']);

    // XTREAM CODES compatible API
    Route::get('/player_api.php', [AuthController::class, 'xtreamAction']);

    // Live streaming endpoints
    Route::get('/live/{channelId}/{streamKey}.m3u8', function ($channelId, $streamKey) {
        $stream = \App\Models\Stream::where('stream_key', $streamKey)
            ->where('channel_id', $channelId)
            ->active()
            ->first();

        if (!$stream) {
            abort(404, 'Stream not found or offline');
        }

        $hlsPath = config('streaming.hls_path') . "/{$streamKey}/index.m3u8";
        if (!file_exists($hlsPath)) {
            abort(404, 'HLS playlist not available');
        }

        return response()->file($hlsPath, [
            'Content-Type' => 'application/vnd.apple.mpegurl',
        ]);
    });

    Route::get('/live/{channelId}/{streamKey}/{segment}', function ($channelId, $streamKey, $segment) {
        $segmentPath = config('streaming.hls_path') . "/{$streamKey}/{$segment}";
        if (!file_exists($segmentPath)) {
            abort(404, 'Segment not found');
        }

        return response()->file($segmentPath, [
            'Content-Type' => 'video/MP2T',
        ]);
    });
});

// ===================== ADMIN API (Sanctum Token Auth) =====================
Route::middleware(['auth:sanctum', \App\Http\Middleware\AdminMiddleware::class])
    ->prefix('admin')
    ->group(function () {

        // Dashboard
        Route::get('/dashboard', [DashboardController::class, 'index']);

        // Channels
        Route::apiResource('channels', ChannelController::class);
        Route::post('channels/bulk-import', [ChannelController::class, 'bulkImport']);
        Route::get('channels/export/m3u', [ChannelController::class, 'exportM3u']);

        // Streams
        Route::get('streams', [StreamController::class, 'index']);
        Route::post('streams/restream', [StreamController::class, 'startRestream']);
        Route::post('streams/{stream}/stop', [StreamController::class, 'stop']);
        Route::get('streams/stats', [StreamController::class, 'stats']);
        Route::get('streams/logs', [StreamController::class, 'logs']);

        // Servers
        Route::apiResource('servers', ServerController::class);
        Route::post('servers/{server}/health-check', [ServerController::class, 'healthCheck']);
        Route::get('servers/{server}/rtmp-stats', [ServerController::class, 'rtmpStats']);

        // Users
        Route::apiResource('users', UserController::class);
        Route::post('users/{user}/regenerate-api-key', [UserController::class, 'regenerateApiKey']);
        Route::post('users/bulk-create', [UserController::class, 'bulkCreate']);

        // Categories
        Route::apiResource('categories', CategoryController::class);
    });