<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return redirect('/admin');
});

Route::get('/admin/{any?}', function () {
    $indexPath = public_path('../frontend/dist/index.html');
    if (file_exists($indexPath)) {
        return file_get_contents($indexPath);
    }
    return view('admin.dashboard');
})->where('any', '.*');